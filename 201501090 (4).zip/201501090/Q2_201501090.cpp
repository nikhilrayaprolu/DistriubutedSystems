#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <string>
#include <string.h>
#include <iostream>
#include <string>
using namespace std;
void merge(int *, int *, int, int, int);
void mergeSort(int *, int *, int, int);
void printarguments(string value){
    //cout<<value;
}
void printint(int value){
    //cout<<value;
}

int main(int argc, char** argv) {
    /********** Initialize MPI **********/
    int world_rank;
    int world_size;

    MPI_Init(&argc, &argv);
    printarguments("MPI initialised");
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    printarguments("world rank of the process");
    printint(world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    int n ;
    if(world_rank==0)
        scanf("%d",&n);
    int *original_array = (int*)malloc(n * sizeof(int));
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int c;
    srand(time(NULL));
    if(world_rank==0){
        for(c = 0; c < n; c++) {
            int op;
            scanf("%d",&op);
            original_array[c] = op;
        }
    }
    /********** Divide the array in equal-sized chunks **********/
    int size = n/world_size;
    int rem = (n%world_size);
    printint(size);
    int *sendcounts = (int*)malloc(sizeof(int)*size);
    int *displs = (int*)malloc(sizeof(int)*size);
    int sum = 0;
    for (int i = 0; i < world_size; ) {
        if(i == world_size - 1){
            sendcounts[i] = size+rem;
            printint(sendcounts[i]);
        }else {
            sendcounts[i] = size;
            printint((sendcounts[i]));
        }
        displs[i] = sum;
        sum += sendcounts[i];
        printint(sum);
        i++;
    }
    /********** Send each subarray to each process **********/
    int *sub_array = (int*)malloc(sendcounts[world_rank] * sizeof(int));
    printarguments("subarray created");
    MPI_Scatterv(original_array, sendcounts,displs,MPI_INT, sub_array, sendcounts[world_rank], MPI_INT, 0, MPI_COMM_WORLD);
    printarguments("scattered the original array to other processes");
    /********** Perform the mergesort on each process **********/
    int *tmp_array = (int*)malloc(size * sizeof(int));
    printarguments("started individual mergeSort");
    mergeSort(sub_array, tmp_array, 0, (size - 1));


    /********** Gather the sorted subarrays into one **********/

    int *sorted = NULL;
    if(world_rank == 0) {
        printarguments("created sorted array");
        sorted = (int*)malloc(n * sizeof(int));

    }
    printarguments("gathering sorted arrays");
    MPI_Gatherv(sub_array, sendcounts[world_rank], MPI_INT, sorted, sendcounts,displs, MPI_INT, 0, MPI_COMM_WORLD);
    /********** Make the final mergeSort call **********/
    if(world_rank == 0) {
        printarguments("final merge sort of the whole array");
        int *other_array = (int*)malloc(n * sizeof(int));
        mergeSort(sorted, other_array, 0, (n - 1));
        printarguments("showing the final sorted array");
        /********** Display the sorted array **********/
        for(c = 0; c < n; ) {

            printf("%d ", sorted[c]);
            c++;
        }

        printf("\n");

        printarguments("free up all root elements");
        free(sorted);
        free(other_array);

    }

    printarguments("free up all original elements");
    free(original_array);
    free(sub_array);
    free(tmp_array);

    printarguments("finalise MPI program");
    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Finalize();

}

/********** Merge Function **********/
void merge(int *a, int *b, int l, int m, int r) {

    int h;
    int i;
    int j;
    int  k;
    h = l;
    i = l;
    j = m;
    j = j + 1;

    while((h <= m) && (j <= r)) {
        if(a[h] <= a[j]) {
            printint(b[i]);
            b[i] = a[h];
            h++;

        }

        else {
            printint(b[i]);
            b[i] = a[j];
            j++;

        }
        printarguments("increment i");
        i++;

    }

    if(m < h) {

        for(k = j; k <= r; ) {
            printint(b[i]);
            b[i] = a[k];
            i++;
            k++;

        }

    }

    else {

        for(k = h; k <= m; k++) {
            printint(b[i]);
            b[i] = a[k];
            i++;

        }

    }

    for(k = l; k <= r; k++) {
        printint(b[k]);
        a[k] = b[k];

    }

}

/********** Recursive Merge Function **********/
void mergeSort(int *a, int *b, int l, int r) {

    int m;

    if(l < r) {
        printint(l);
        m = (l + r)/2;
        printint(m);
        mergeSort(a, b, l, m);
        mergeSort(a, b, (m + 1), r);
        printarguments("merging left and right parts");
        merge(a, b, l, m, r);

    }

}