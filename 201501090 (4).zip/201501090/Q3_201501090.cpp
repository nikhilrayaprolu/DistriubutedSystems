#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <string>
#include <string.h>
#include <iostream>
#include <string>
int size;
int rank;
int* MatrixChunk;
int mSize;
int* displs;
void printarguments(std::string value){
    //cout<<value;
}

int* sendcounts;
typedef struct { int v1; int v2; } Edge;
int* MST;
void printint(int value){
    //cout<<value;
}

int minWeight;
int edgeCount;

int main(int argc,char *argv[])
{
    printarguments("Initialising MPI");
    MPI_Init ( &argc, &argv );
    MPI_Comm_rank ( MPI_COMM_WORLD, &rank);
    MPI_Comm_size ( MPI_COMM_WORLD, &size );
    printint(rank);
    printint(size);
    srand(time(NULL) + rank);

    if (rank==0)
    {
        scanf("%d",&mSize);
        scanf("%d",&edgeCount);
        printint(mSize);
    }

    MPI_Bcast(&mSize, 1, MPI_INT, 0, MPI_COMM_WORLD);
    printarguments("broadcasted the msize");
    /************************************************/
    int i,j,k;
    printarguments("make required displs and sendcounts");
    displs = (int*)malloc(sizeof(int) * size);
    sendcounts = (int*)malloc(sizeof(int) * size);
    sendcounts[0] = mSize / size;

    int remains = size - (mSize % size);
    displs[0] = 0;


    printarguments("reamains to be added to last elements");

    for (i = 1; i < remains; )
    {
        sendcounts[i] = sendcounts[0];
        displs[i] = displs[i - 1] ;
        displs[i] += sendcounts[i - 1];
        ++i;
    }
    for (i = remains; i < size; )
    {
        sendcounts[i] = sendcounts[0] + 1;
        displs[i] = displs[i - 1];
        displs[i] += sendcounts[i - 1];
        ++i;
    }


    int* matrix;
    if (rank==0)
    {
        printarguments("initial matrix created");
        matrix = (int*)malloc(mSize*mSize*sizeof(int));
        printarguments("initialise matrix to 1000");
        for (i = 0; i < mSize;  )
        {
            matrix[mSize*i+j]=0;
            for(j = 0; j < mSize;  )
            {
                if(i!=j)
                    matrix[mSize*i+j]=10000;
                ++j;
            }
            ++i;
        }
        printarguments("scan given elements");
        for(i=0;i<edgeCount;)
        {
            int y1,y2,y3;
            scanf("%d %d %d",&y1,&y2,&y3);
            y1--;y2--;
            printint(y1);

            if(y1>y2)
            {
                int temp=y1;
                y1=y2;
                y2=temp;
            }
            printint(y2);
            matrix[mSize*y1+y2]=y3;
            matrix[mSize*y2+y1]=y3;
            i++;
        }
    }
    printarguments("create martrix chunk to distribute weights");
    MatrixChunk = (int*)malloc(sendcounts[rank]*mSize*sizeof(int));
    printarguments("special datatype for sending array of ints");
    MPI_Datatype matrixString;
    MPI_Type_contiguous(mSize,MPI_INT, &matrixString);
    MPI_Type_commit(&matrixString);
    printarguments("scattering the matrix");
    MPI_Scatterv(matrix,sendcounts,displs,matrixString,MatrixChunk,sendcounts[rank],matrixString,0,MPI_COMM_WORLD);

    MST = (int*)malloc(sizeof(int)*mSize); // max size is number of vertices
    for ( i = 0; i < mSize; )
    {
        MST[i] = -1;
        ++i;
    }

    double start;

    start = MPI_Wtime();

    MST[0] = 0;
    minWeight = 0;
    printarguments("Finding the minimum edge vertex");
    int min;
    int v1 = 0;
    int v2 = 0;

    struct { int min; int rank; } minRow, row;
    Edge edge;
    for ( k = 0; k < mSize - 1; ++k)
    {
        min = INT_MAX;
        printint(min);
        for ( i = 0; i < sendcounts[rank]; ++i)
        {   printint(i);
            if (MST[i + displs[rank]] != -1)
            {   printint(MST[i + displs[rank]]);
                for ( j = 0; j < mSize; ++j)
                {
                    printarguments("looping for j");
                    if (MST[j] == -1)
                    {
                        if ( MatrixChunk[mSize*i+j] < min && MatrixChunk[mSize*i+j] != 0)
                        {
                            min = MatrixChunk[mSize*i+j];
                            printint(min);
                            v2 = j;
                            v1 = i;
                        }
                    }
                }
            }
        }

        row.min = min;
        row.rank = rank;
        printint(row.min);
        MPI_Allreduce(&row, &minRow, 1, MPI_2INT, MPI_MINLOC, MPI_COMM_WORLD);
        printarguments("Calling All reduce to calculate global minimum");
        edge.v1 = v1 + displs[rank];
        edge.v2 = v2;
        printarguments("Calling Broadcast to finally announce the global minimum and edge");
        MPI_Bcast(&edge, 1, MPI_2INT, minRow.rank, MPI_COMM_WORLD);

        MST[edge.v2] = edge.v1;
        minWeight += minRow.min;
        printint(minWeight);
    }
    /**************************************************************/
    double finish, calc_time;
    finish = MPI_Wtime();
    calc_time = finish-start;

    if (rank == 0)
    {   printint(minWeight);
        printf("%d\n",minWeight);
    }
    printarguments("Finally ending the MPI program");
    MPI_Finalize();
    return 0;
}
