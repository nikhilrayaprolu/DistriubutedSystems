#include <iostream>
#include<mpi.h>
#include<iostream>
#include <fstream>
#include<vector>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include<mpi.h>
#include <math.h>
#include <string.h>

using namespace std;
void printarguments(string value){
    //cout<<value;
}
void printint(int value){
    //cout<<value;
}

int main(int argc,char **argv)
{
    printarguments("initialising the MPI environment");
    MPI_Init(&argc, &argv);

    int world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    printint(world_size);
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    printint(rank);
    int inputlines;
    int size;
    int remsize;
    vector<string> ans;
    int colines;
    char* word;
    int word_size;

    if(rank==0)
    {
        printarguments("read the complete file");
        ifstream file_input;
        string filepath;
        filepath = argv[1];
        word = argv[2];
        word_size = strlen(word);
        printint(word_size);
        colines = 0;
        file_input.open(filepath.c_str());
        string line;
        while (getline(file_input, line))
        {

            ans.push_back(line);
            colines++;
            printint(colines);
        }
        file_input.close();
        int temp = colines/(world_size-1);
        printint(temp);
        int rem = colines%(world_size-1);
        printint(rem);
        int off=0;
        vector<string>::iterator it = ans.begin();
        for(int i=1;i<world_size-1;i++)
        {
            printint(i);
            for(int j=0;j<temp;j++)
            {
                printint(j);
                int x = it->size();
                printarguments("sending values to respective");
                MPI_Send(&x,1,MPI_INT,i,0,MPI_COMM_WORLD);
                printarguments("sending it data");
                MPI_Send(it->data(),x,MPI_BYTE,i,0,MPI_COMM_WORLD);

                it++;
                printarguments("sednding done");
            }
            off+=temp;
        }
        for(int j=0;j<temp+rem;j++)
        {
            int x = it->size();
            printint(x);
            printarguments("sending values to respective");
            MPI_Send(&x,1,MPI_INT,world_size-1,0,MPI_COMM_WORLD);
            printarguments("sending it data");
            MPI_Send(it->data(),x,MPI_BYTE,world_size-1,0,MPI_COMM_WORLD);
            it++;
            printarguments("sending done");
        }
    }
    printarguments("broadcasting colines to all processes");
    MPI_Bcast(&colines, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&word_size, 1,MPI_INT, 0, MPI_COMM_WORLD);
    printarguments("broadcasting wordsize to all processes");
    if(rank!=0)
    {
        word = (char*)malloc(word_size*sizeof(char));
    }
    printarguments("broadcasting word to all processes");
    MPI_Bcast(word,word_size,MPI_BYTE,0,MPI_COMM_WORLD);
    word[word_size]='\0';

    size = colines/(world_size-1);
    printint(size);
    remsize = colines%(world_size-1);
    printint(remsize);

    if(rank!=0)
    {
        char * tok = NULL;
        if(rank==world_size-1)
        {
            printint(rank);
            for(int i=0;i<size+remsize;i++)
            {
                int recv_size;
                printint(i);
                MPI_Recv(&recv_size,1,MPI_INT,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                printarguments("receiving values from respective processes");
                tok = new char[recv_size+1];
                MPI_Recv(tok,recv_size,MPI_BYTE,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                printarguments("receiving tokes from processes");

                tok[recv_size]='\0';
                printint(rank);
                vector<string> v;
                v.push_back(tok);
                vector<string> :: iterator it=v.begin();
                printarguments("finding the word in line");
                if (it->find(word) != string::npos)
                {
                    int x = it->size();
                    printint(x);
                    MPI_Send(&x,1,MPI_INT,0,0,MPI_COMM_WORLD);
                    printarguments("sending x to processes");
                    MPI_Send(it->data(),x,MPI_BYTE,0,0,MPI_COMM_WORLD);
                }
                else
                {
                    printarguments("sending x to processes");
                    int x = -1;
                    MPI_Send(&x,1,MPI_INT,0,0,MPI_COMM_WORLD);
                    MPI_Send("r",1,MPI_BYTE,0,0,MPI_COMM_WORLD);
                    printarguments("sent the value r and x");
                }
            }
        }
        else
        {
            for(int i=0;i<size;i++)
            {
                int recv_size;
                printarguments("receiving size from root");
                MPI_Recv(&recv_size,1,MPI_INT,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                printint(recv_size);
                tok = new char[recv_size+1];
                MPI_Recv(tok,recv_size,MPI_BYTE,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                printarguments("receive tokens from root");
                tok[recv_size]='\0';
                vector<string> v;
                v.push_back(tok);
                printarguments("checking for word");
                vector<string> :: iterator it=v.begin();

                if (it->find(word) != string::npos)
                {
                    printarguments("sending final values to root");
                    int x = it->size();
                    MPI_Send(&x,1,MPI_INT,0,0,MPI_COMM_WORLD);
                    //cout<<it->data()<<endl;
                    printint(x);
                    MPI_Send(it->data(),x,MPI_BYTE,0,0,MPI_COMM_WORLD);
                }
                else
                {
                    printarguments("sending final values to root");
                    int x = -1;
                    MPI_Send(&x,1,MPI_INT,0,0,MPI_COMM_WORLD);
                    printint(x);
                    MPI_Send("r",1,MPI_BYTE,0,0,MPI_COMM_WORLD);
                }
            }
        }
    }
    if(rank==0)
    {
        int total=0;
        printint(total);
        char *tok;
        for(int i=1;i<world_size-1;i++)
        {
            printint(i);
            for(int j=0;j<size;j++)
            {
                int recv_size;
                printarguments("receive size from other processes");
                MPI_Recv(&recv_size,1,MPI_INT,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                printint(recv_size);
                if(recv_size!=-1)
                {   printarguments("receive tokens from processes");
                    tok = new char[recv_size+1];
                    MPI_Recv(tok,recv_size,MPI_BYTE,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                    tok[recv_size]='\0';
                    cout<<tok<<endl;
                    printint(total);
                    total++;
                }
                else
                {
                    tok = new char[1];
                    printarguments("receive tokens from processes");
                    MPI_Recv(tok,1,MPI_BYTE,i,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                }
            }
        }
        printarguments("receiving for the remainng elements");
        for(int j=0;j<size+remsize;j++)
        {
            int recv_size;
            printarguments("receive size from other processes");
            MPI_Recv(&recv_size,1,MPI_INT,world_size-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            if(recv_size!=-1)
            {
                printarguments("receive tokens from other processes");
                tok = new char[recv_size+1];
                MPI_Recv(tok,recv_size,MPI_BYTE,world_size-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
                tok[recv_size]='\0';
                printarguments(tok);
                cout<<tok<<endl;
                total++;
                printint(total);
            }
            else
            {
                tok = new char[1];
                printarguments("receive tokens from other processes");
                MPI_Recv(tok,1,MPI_BYTE,world_size-1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            }
        }
        cout<<"total="<<total<<endl;
    }
    MPI_Finalize();
}