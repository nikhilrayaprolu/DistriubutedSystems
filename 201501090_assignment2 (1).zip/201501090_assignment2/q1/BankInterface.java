import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;

// Creating Remote interface for our application 
public interface BankInterface extends Remote {
    int deposit(int acc_no,int amt) throws RemoteException;
    int withdraw(int acc_no,int amt) throws RemoteException;
    int balance(int acc_no) throws RemoteException;
    ArrayList<Transaction> tranactioin_details(int acc_no,Date start_date,Date end_data) throws RemoteException;
    ArrayList<Transaction> tranactioin_details(int acc_no) throws RemoteException;

} 