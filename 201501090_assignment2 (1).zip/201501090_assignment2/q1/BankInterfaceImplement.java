import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

// Implementing the remote interface
public class BankInterfaceImplement implements BankInterface {
    ArrayList<User> BankUsers = new ArrayList<User>();
    public BankInterfaceImplement() {
        User user1 = new User(1,1,97018247,1000,"nikhil",0);
        User user2 = new User(2,2,97018247,1000,"raj",0);
        User user3 = new User(3,3,97018247,1000,"surya",0);
        User user4 = new User(4,4,97018247,1000,"kaja",0);
        User user5 = new User(5,5,97018247,1000,"rajnikanth",0);
        User user6 = new User(6,6,97018247,1000,"einstein",0);
        BankUsers.addAll(Arrays.asList(user1,user2,user3,user4,user5,user6));
    }
    @Override
    public int deposit(int acc_no, int amt) throws RemoteException {
        int previousbalance = BankUsers.get(acc_no-1).getBalance();
        int presentbalance = previousbalance + amt;
        Date time = new Date();
        BankUsers.get(acc_no-1).setBalance(presentbalance);
        BankUsers.get(acc_no-1).setTransactionhistory(acc_no,previousbalance,presentbalance,time);
        return BankUsers.get(acc_no-1).getBalance();
    }

    @Override
    public int withdraw(int acc_no, int amt) throws RemoteException {
        int previousbalance = BankUsers.get(acc_no-1).getBalance();
        int presentbalance = previousbalance - amt;
        BankUsers.get(acc_no-1).setBalance(presentbalance);
        Date time = new Date();
        BankUsers.get(acc_no-1).setTransactionhistory(acc_no,previousbalance,presentbalance,time);
        return BankUsers.get(acc_no-1).getBalance();
    }

    @Override
    public int balance(int acc_no) throws RemoteException {
        return BankUsers.get(acc_no-1).getBalance();
    }

    @Override
    public ArrayList<Transaction> tranactioin_details(int acc_no, Date start_date, Date end_date) throws RemoteException {
        ArrayList<Transaction> finaltransactions = new ArrayList<Transaction>();
        for(Transaction t:BankUsers.get(acc_no-1).getTransactionhistory()){
            if(t.getTime().getTime() > start_date.getTime() && t.getTime().getTime() < end_date.getTime()){
                finaltransactions.add(t);
            }
        }
        return finaltransactions;
    }

    @Override
    public ArrayList<Transaction> tranactioin_details(int acc_no) throws RemoteException {
        return BankUsers.get(acc_no-1).getTransactionhistory();
    }

    // Implementing the interface method

}
