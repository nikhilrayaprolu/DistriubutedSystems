import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Client {
    private Client() {}
    public static void printTransactions(BankInterface stub, int acc_no, String start_date, String end_date){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date start_date1 = sdf.parse(start_date);
            Date end_date1 = sdf.parse(end_date	);
            ArrayList<Transaction> transactions = stub.tranactioin_details(acc_no,start_date1,end_date1);
            System.out.println(" Transaction_Id        Type            Final Amount");
            for(Transaction t:transactions){
                System.out.println(t.getPresentbalance()+ ' ' + t.getPreviousbalance()+ ' ' + t.getAmt());
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    public static void printTransactions(BankInterface stub, int acc_no){
        try {
            ArrayList<Transaction> transactions = stub.tranactioin_details(acc_no);
            System.out.println("Present Balance Debit/Credit Final Amount");
            for(Transaction t:transactions){
                System.out.print(" "+t.getPresentbalance() + " " + t.getAmt() + " "+ t.getPreviousbalance()+" ");
                System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(t.getTime()));
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }

    }
    public static void main(String[] args) {
        try {
            // Getting the registry
            Registry registry = LocateRegistry.getRegistry(null);

            // Looking up the registry for the remote object
            BankInterface stub = (BankInterface) registry.lookup("BankInterface");

            // Calling the remote method using the obtained object
            //System.out.println(stub.balance(1));
            //stub.deposit(1,100);
            //System.out.println(stub.balance(1));
            // System.out.println("Remote method invoked");
            //stub.withdraw(1,100);
            //System.out.println(stub.balance(1));
            //printTransactions(stub,1);
            //printTransactions(stub,1,"2017-09-13 02:40:09","2017-09-13 02:40:11");

            Scanner sc=new Scanner(System.in);
            System.out.print("Enter your account Number");
            int acc_no = sc.nextInt();
            String in;
            while((in=sc.nextLine())!=null)
            {   System.out.println(in);
                String[] splited = in.split("\\s+");
                if(new String("deposit").equals(splited[0]) && splited.length==2)
                    stub.deposit(acc_no,Integer.parseInt(splited[1]));
                if(new String("withdraw").equals(splited[0]) && splited.length==2)
                    stub.withdraw(acc_no,Integer.parseInt(splited[1]));
                if(new String("balance").equals(splited[0]) && splited.length==1)
                    System.out.println(stub.balance(acc_no));
                if(new String("transaction_details").equals(splited[0]) && splited.length==1)
                    printTransactions(stub,acc_no);
                if(new String("transaction_details").equals(splited[0]) && splited.length==3)
                {
                    printTransactions(stub,acc_no,splited[1],splited[2]);
                }
                if(new String("done").equals(splited[0]))
                {
                    System.out.println("ThankYou");
                    System.out.println("Enter Your account Number");
                    acc_no = sc.nextInt();

                }
                System.out.print(">>");
            }

        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
