import java.io.Serializable;
import java.util.Date;

public class Transaction implements Serializable {
    private int  acc_no,previousbalance,presentbalance,amt;
    private Date time;

    public Transaction(int acc_no, int previousbalance, int presentbalance, Date time) {
        this.acc_no = acc_no;
        this.previousbalance = previousbalance;
        this.presentbalance = presentbalance;
        this.amt=presentbalance - previousbalance;
        this.time = time;
        System.out.println("previousbalance:"+ this.previousbalance);
    }

    public int getAcc_no() {
        return acc_no;
    }

    public void setAcc_no(int acc_no) {
        this.acc_no = acc_no;
    }

    public int getPreviousbalance() {
        return previousbalance;
    }

    public void setPreviousbalance(int previousbalance) {
        this.previousbalance = previousbalance;
    }

    public int getPresentbalance() {
        return presentbalance;
    }

    public void setPresentbalance(int presentbalance) {
        this.presentbalance = presentbalance;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public int getAmt() {
        return amt;
    }

    public void setAmt(int amt) {
        this.amt = amt;
    }
}
