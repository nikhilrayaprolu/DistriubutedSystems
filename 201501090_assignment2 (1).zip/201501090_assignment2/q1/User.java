import java.util.ArrayList;
import java.util.Date;

public class User implements java.io.Serializable {
    private int id, accountid, contactinfo, balance,type;
    private String name;
    private ArrayList<Transaction> transactionhistory = new ArrayList<Transaction>();

    public User(int id, int accountid, int contactinfo, int balance, String name,int type) {
        this.id = id;
        this.accountid = accountid;
        this.contactinfo = contactinfo;
        this.balance = balance;
        this.name = name;
        this.type = type;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getAccoundId() {
        return accountid;
    }

    public int getContact() {
        return contactinfo;
    }
    public int getBalance() {
        return balance;
    }
    public ArrayList<Transaction> getTransactionhistory() {
        return transactionhistory;
    }
    public void setID(int id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setContactinfo(int contactinfo) {
        this.contactinfo = contactinfo;
    }

    public void setBalance(int balance) {
        this.balance = balance;

    }

    public void setAccountid(int accountid) {
        this.accountid = accountid;
    }
    public void setTransactionhistory(int acc_no,int previousbalance,int presentbalance,Date time){
        Transaction transaction = new Transaction(acc_no,previousbalance,presentbalance,time);
        transactionhistory.add(transaction);
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}