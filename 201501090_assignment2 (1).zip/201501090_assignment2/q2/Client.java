package q2;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Random;
import java.util.Scanner;

public class Client {
    private static Random r = new Random();
    public static String key;
    private static int generateRandom(int min, int max) {
        int value = r.nextInt(max-min+1);
        value = value +  + min;
        return value;
    }
    private static void printBigInteger(BigInteger num){
        //System.out.println(num);
    }
    private static void printmessage(String message){
        //System.out.println(message);
    }
    public static void exchangeKeys(ServerInterface stub) throws RemoteException {
        int p = 23;
        int g = 5;
        int a = generateRandom(2,p-1);
        BigInteger generator = new BigInteger(Integer.toString(g));
        printBigInteger(generator);
        BigInteger exponent=new BigInteger(Integer.toString(a));
        printBigInteger(exponent);
        BigInteger modulus=new BigInteger(Integer.toString(p));
        printBigInteger(modulus);
        BigInteger A=generator.modPow(exponent,modulus);
        String sendA=A.toString();
        printmessage(sendA);
        String B=stub.DHKey(p,g,sendA);
        BigInteger Bval=new BigInteger(B);
        printBigInteger(Bval);
        BigInteger Key=Bval.modPow(exponent,modulus);
        key=Key.toString();
        printmessage(key);
    }
    public static byte[] Encode(String a,String key)throws UnsupportedEncodingException
    {

        byte[] out = new byte[a.length()];
        printmessage(a);
        for (int i = 0; i < a.length(); ) {
            out[i] = (byte) (a.charAt(i)^key.charAt(i%key.length()));
            i++;
        }

        return out;

    }
    public static String Decode(byte[] arr,String key)throws UnsupportedEncodingException
    {
        byte[] keys=key.getBytes();
        int i;
        printmessage(key);
        for(i=0;i<arr.length;){
            arr[i]=(byte)(arr[i]^keys[i%keys.length]);
            i++;
        }

        String str = new String(arr, "UTF-8");
        printmessage(str);
        return str;
    }
    public static void primality_test(ServerInterface access,String a)throws RemoteException,UnsupportedEncodingException {
        byte[] request = Encode(a,key);
        byte[] arr = access.primality_test(request);
        String message = Decode(arr,key);
        System.out.println(message);
    }
    public static void palindrome_test(ServerInterface access,String a)throws RemoteException,UnsupportedEncodingException	{
        byte[] request = Encode(a,key);
        byte[] arr = access.palindrome_test(request);
        String message = Decode(arr,key);
        System.out.println(message);
    }
    public static void string_case_converter(ServerInterface access,String a)throws RemoteException,UnsupportedEncodingException{
        byte[] request = Encode(a,key);
        byte[] arr = access.string_case_converter(request);
        String message = Decode(arr,key);
        System.out.println(message);
    }
    public static void fibnoacci_number(ServerInterface access,int a)throws RemoteException,UnsupportedEncodingException{
        byte[] request = Encode(Integer.toString(a),key);
        byte[] arr = access.fibnoacci_number(request);
        String message = Decode(arr,key);
        System.out.println(message);
    }
    public static void main(String[] args) throws UnsupportedEncodingException, RemoteException {
        ServerInterface stub = null;
        try {
            stub=(ServerInterface) Naming.lookup("rmi://localhost:1900"+"/RMI");

    //            Registry registry = LocateRegistry.getRegistry(null);
    //           stub = (ServerInterface) registry.lookup("ServerInterface");

        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        exchangeKeys(stub);
        Scanner sc=new Scanner(System.in);
        String in;
        while((in=sc.nextLine())!=null) {
            System.out.println(in);
            String[] splited = in.split("\\s+");
            if (new String("primality").equals(splited[0]) && splited.length == 2)
                primality_test(stub, (splited[1]));
            if (new String("palindrome").equals(splited[0]) && splited.length == 2)
                palindrome_test(stub, (splited[1]));
            if (new String("caseconvert").equals(splited[0]) && splited.length == 2)
                string_case_converter(stub, (splited[1]));
            if (new String("fibonacci").equals(splited[0]) && splited.length == 2)
                fibnoacci_number(stub, Integer.parseInt(splited[1]));

            System.out.print(">>");
        }

    }
}
