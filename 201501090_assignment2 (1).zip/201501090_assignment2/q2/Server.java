package q2;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

public class Server extends ServerInterfaceImplementation{
    public static void main(String args[]){
        ServerInterfaceImplementation obj = new ServerInterfaceImplementation();
        try {
            ServerInterface stub = (ServerInterface) UnicastRemoteObject.exportObject(obj, 0);
            Registry registry=LocateRegistry.createRegistry(1900);
            Naming.rebind("rmi://localhost:1900"+"/RMI", stub);
            System.setProperty("java.security.policy","file:test.policy");
            //Registry registry = LocateRegistry.getRegistry();
            //registry.bind("ServerInterface", stub);
            System.err.println("Server ready");
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
}
