package q2;

import java.io.UnsupportedEncodingException;
import java.rmi.Remote;
import java.rmi.RemoteException;

// Creating Remote interface for our application 
public interface ServerInterface extends Remote {
    public  byte[] primality_test(byte[]arr) throws RemoteException, UnsupportedEncodingException;
    public byte[] palindrome_test(byte[]arr) throws RemoteException, UnsupportedEncodingException;
    public byte[] fibnoacci_number(byte[] input) throws RemoteException, UnsupportedEncodingException;
    public byte[] string_case_converter(byte[] a) throws RemoteException, UnsupportedEncodingException;
    public String DHKey(int p,int g,String recv) throws RemoteException;
} 