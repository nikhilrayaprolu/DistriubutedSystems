package q2;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Random;

public class ServerInterfaceImplementation implements ServerInterface {


public static String key;
public static Random r = new Random();
public static Long fib[] = new Long[1000009];
public ServerInterfaceImplementation() {
        Arrays.fill(fib, -1L);
        }
private static int generateRandom(int min, int max) {
        return r.nextInt(max-min+1) + min;
        }
private static void printmessage(String a) {
        //System.out.println(a);
        }
public static byte[] toBytes(int i)
        {
        byte[] result = new byte[4];

        result[0] = (byte) (i >> 24);
        result[1] = (byte) (i >> 16);
        result[2] = (byte) (i >> 8);
        result[3] = (byte) (i /*>> 0*/);

        return result;
        }
public static byte[] Encode(String a,String key)
        {
        printmessage(a);
        byte[] out = new byte[a.length()];
        printmessage(key);
        for (int i = 0; i < a.length();) {
        out[i] = (byte) (a.charAt(i)^key.charAt(i%key.length()));
        i++;
        }
        return out;

        }
public static String Decode(byte[] arr,String key)throws UnsupportedEncodingException
        {
        byte[] keys = key.getBytes();
        int i;
        printmessage(key);
        for(i = 0;i < arr.length;){
        arr[i]=(byte)(arr[i]^keys[i%keys.length]);
        i++;
        }

        String str = new String(arr, "UTF-8");
        printmessage(str);
        return str;
        }

public String DHKey(int p,int g,String recv) throws RemoteException
        {
        System.err.println(p + " " + g + " " + recv);
        int range = p;
        int rand = generateRandom(2,p-1);
        int A = Integer.parseInt(recv);
        printmessage(recv);
        BigInteger generator = new BigInteger(Integer.toString(g));
        System.out.println(generator);
        BigInteger random = new BigInteger(Integer.toString(rand));
        System.out.println(random);
        BigInteger modulus = new BigInteger(Integer.toString(p));
        System.out.println(modulus);
        BigInteger bval = generator.modPow(random,modulus);
        String b = bval.toString();
        System.out.println(b);
        BigInteger Aval = new BigInteger(recv);
        BigInteger Key = Aval.modPow(random,modulus);
        key = Key.toString();
        System.out.println(Key);
        return b;
        }
public  byte[] primality_test(byte[]arr) throws RemoteException, UnsupportedEncodingException {
        String input =Decode(arr,key);
        String decoded=(input);
        printmessage(decoded);
        int a=Integer.parseInt(decoded);
        int i = 2;
        for(i = 2;i*i <= a;)
        {
        if(a%i == 0)
        return Encode("False",key);
        i++;

        }
        return Encode("True",key);

        }
public byte[] palindrome_test(byte[]arr) throws RemoteException, UnsupportedEncodingException {
        String decod=Decode(arr,key);
        String reverse = new StringBuffer(decod).reverse().toString();

        if (decod.equals(reverse))
        return Encode("True",key);

        else
        return Encode("False",key);
        }

public Long Fibbi(int n)
        {
        if(n == 1)
        {
        return 1L;
        }

        if(n == 0)
        {
        return 0L;}
        if(fib[n]!=-1L)
        return fib[n];
        fib[n] = Fibbi(n-1);
        fib[n] = fib[n] +Fibbi(n-2);
        return fib[n];

        }
public byte[] fibnoacci_number(byte[] input) throws RemoteException, UnsupportedEncodingException {
        String in = Decode(input,key);
        printmessage(in);
        int n = Integer.parseInt(in);
        Long ans = Fibbi(n);
        System.out.println(ans);
        return Encode(Long.toString(ans),key);
        }
public byte[] string_case_converter(byte[] a) throws RemoteException, UnsupportedEncodingException {
        String input=Decode(a,key);
        printmessage(input);
        int size=input.length();
        char[] chars = input.toCharArray();
        for (int i = 0; i < chars.length; i++)
        {
        char c = chars[i];
        if (Character.isUpperCase(c))
        {
        chars[i] = Character.toLowerCase(c);
        }
        else if (Character.isLowerCase(c))
        {
        chars[i] = Character.toUpperCase(c);
        }
        }
        return Encode(new String(chars),key);


        }
        }
