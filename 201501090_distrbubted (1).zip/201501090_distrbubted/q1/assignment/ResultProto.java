package assignment;

public final class ResultProto {
    private ResultProto() {}
    public static void registerAllExtensions(
            com.google.protobuf.ExtensionRegistryLite registry) {
    }

    public static void registerAllExtensions(
            com.google.protobuf.ExtensionRegistry registry) {
        registerAllExtensions(
                (com.google.protobuf.ExtensionRegistryLite) registry);
    }
    public interface CourseMarksOrBuilder extends
            // @@protoc_insertion_point(interface_extends:CourseMarks)
            com.google.protobuf.MessageOrBuilder {

        /**
         * <code>optional string name = 1;</code>
         */
        java.lang.String getName();
        /**
         * <code>optional string name = 1;</code>
         */
        com.google.protobuf.ByteString
        getNameBytes();

        /**
         * <code>optional int32 score = 2;</code>
         */
        int getScore();
    }
    /**
     * Protobuf type {@code CourseMarks}
     */
    public  static final class CourseMarks extends
            com.google.protobuf.GeneratedMessageV3 implements
            // @@protoc_insertion_point(message_implements:CourseMarks)
            CourseMarksOrBuilder {
        // Use CourseMarks.newBuilder() to construct.
        private CourseMarks(com.google.protobuf.GeneratedMessageV3.Builder<?> builder) {
            super(builder);
        }
        private CourseMarks() {
            name_ = "";
            score_ = 0;
        }

        @java.lang.Override
        public final com.google.protobuf.UnknownFieldSet
        getUnknownFields() {
            return com.google.protobuf.UnknownFieldSet.getDefaultInstance();
        }
        private CourseMarks(
                com.google.protobuf.CodedInputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            this();
            int mutable_bitField0_ = 0;
            try {
                boolean done = false;
                while (!done) {
                    int tag = input.readTag();
                    switch (tag) {
                        case 0:
                            done = true;
                            break;
                        default: {
                            if (!input.skipField(tag)) {
                                done = true;
                            }
                            break;
                        }
                        case 10: {
                            java.lang.String s = input.readStringRequireUtf8();

                            name_ = s;
                            break;
                        }
                        case 16: {

                            score_ = input.readInt32();
                            break;
                        }
                    }
                }
            } catch (com.google.protobuf.InvalidProtocolBufferException e) {
                throw e.setUnfinishedMessage(this);
            } catch (java.io.IOException e) {
                throw new com.google.protobuf.InvalidProtocolBufferException(
                        e).setUnfinishedMessage(this);
            } finally {
                makeExtensionsImmutable();
            }
        }
        public static final com.google.protobuf.Descriptors.Descriptor
        getDescriptor() {
            return assignment.ResultProto.internal_static_CourseMarks_descriptor;
        }

        protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
        internalGetFieldAccessorTable() {
            return assignment.ResultProto.internal_static_CourseMarks_fieldAccessorTable
                    .ensureFieldAccessorsInitialized(
                            assignment.ResultProto.CourseMarks.class, assignment.ResultProto.CourseMarks.Builder.class);
        }

        public static final int NAME_FIELD_NUMBER = 1;
        private volatile java.lang.Object name_;
        /**
         * <code>optional string name = 1;</code>
         */
        public java.lang.String getName() {
            java.lang.Object ref = name_;
            if (ref instanceof java.lang.String) {
                return (java.lang.String) ref;
            } else {
                com.google.protobuf.ByteString bs =
                        (com.google.protobuf.ByteString) ref;
                java.lang.String s = bs.toStringUtf8();
                name_ = s;
                return s;
            }
        }
        /**
         * <code>optional string name = 1;</code>
         */
        public com.google.protobuf.ByteString
        getNameBytes() {
            java.lang.Object ref = name_;
            if (ref instanceof java.lang.String) {
                com.google.protobuf.ByteString b =
                        com.google.protobuf.ByteString.copyFromUtf8(
                                (java.lang.String) ref);
                name_ = b;
                return b;
            } else {
                return (com.google.protobuf.ByteString) ref;
            }
        }

        public static final int SCORE_FIELD_NUMBER = 2;
        private int score_;
        /**
         * <code>optional int32 score = 2;</code>
         */
        public int getScore() {
            return score_;
        }

        private byte memoizedIsInitialized = -1;
        public final boolean isInitialized() {
            byte isInitialized = memoizedIsInitialized;
            if (isInitialized == 1) return true;
            if (isInitialized == 0) return false;

            memoizedIsInitialized = 1;
            return true;
        }

        public void writeTo(com.google.protobuf.CodedOutputStream output)
                throws java.io.IOException {
            if (!getNameBytes().isEmpty()) {
                com.google.protobuf.GeneratedMessageV3.writeString(output, 1, name_);
            }
            if (score_ != 0) {
                output.writeInt32(2, score_);
            }
        }

        public int getSerializedSize() {
            int size = memoizedSize;
            if (size != -1) return size;

            size = 0;
            if (!getNameBytes().isEmpty()) {
                size += com.google.protobuf.GeneratedMessageV3.computeStringSize(1, name_);
            }
            if (score_ != 0) {
                size += com.google.protobuf.CodedOutputStream
                        .computeInt32Size(2, score_);
            }
            memoizedSize = size;
            return size;
        }

        private static final long serialVersionUID = 0L;
        @java.lang.Override
        public boolean equals(final java.lang.Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof assignment.ResultProto.CourseMarks)) {
                return super.equals(obj);
            }
            assignment.ResultProto.CourseMarks other = (assignment.ResultProto.CourseMarks) obj;

            boolean result = true;
            result = result && getName()
                    .equals(other.getName());
            result = result && (getScore()
                    == other.getScore());
            return result;
        }

        @java.lang.Override
        public int hashCode() {
            if (memoizedHashCode != 0) {
                return memoizedHashCode;
            }
            int hash = 41;
            hash = (19 * hash) + getDescriptorForType().hashCode();
            hash = (37 * hash) + NAME_FIELD_NUMBER;
            hash = (53 * hash) + getName().hashCode();
            hash = (37 * hash) + SCORE_FIELD_NUMBER;
            hash = (53 * hash) + getScore();
            hash = (29 * hash) + unknownFields.hashCode();
            memoizedHashCode = hash;
            return hash;
        }

        public static assignment.ResultProto.CourseMarks parseFrom(
                com.google.protobuf.ByteString data)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(
                com.google.protobuf.ByteString data,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data, extensionRegistry);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(byte[] data)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(
                byte[] data,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data, extensionRegistry);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(java.io.InputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(
                java.io.InputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input, extensionRegistry);
        }
        public static assignment.ResultProto.CourseMarks parseDelimitedFrom(java.io.InputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseDelimitedWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.CourseMarks parseDelimitedFrom(
                java.io.InputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseDelimitedWithIOException(PARSER, input, extensionRegistry);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(
                com.google.protobuf.CodedInputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.CourseMarks parseFrom(
                com.google.protobuf.CodedInputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input, extensionRegistry);
        }

        public Builder newBuilderForType() { return newBuilder(); }
        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.toBuilder();
        }
        public static Builder newBuilder(assignment.ResultProto.CourseMarks prototype) {
            return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
        }
        public Builder toBuilder() {
            return this == DEFAULT_INSTANCE
                    ? new Builder() : new Builder().mergeFrom(this);
        }

        @java.lang.Override
        protected Builder newBuilderForType(
                com.google.protobuf.GeneratedMessageV3.BuilderParent parent) {
            Builder builder = new Builder(parent);
            return builder;
        }
        /**
         * Protobuf type {@code CourseMarks}
         */
        public static final class Builder extends
                com.google.protobuf.GeneratedMessageV3.Builder<Builder> implements
                // @@protoc_insertion_point(builder_implements:CourseMarks)
                assignment.ResultProto.CourseMarksOrBuilder {
            public static final com.google.protobuf.Descriptors.Descriptor
            getDescriptor() {
                return assignment.ResultProto.internal_static_CourseMarks_descriptor;
            }

            protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
            internalGetFieldAccessorTable() {
                return assignment.ResultProto.internal_static_CourseMarks_fieldAccessorTable
                        .ensureFieldAccessorsInitialized(
                                assignment.ResultProto.CourseMarks.class, assignment.ResultProto.CourseMarks.Builder.class);
            }

            // Construct using assignment.ResultProto.CourseMarks.newBuilder()
            private Builder() {
                maybeForceBuilderInitialization();
            }

            private Builder(
                    com.google.protobuf.GeneratedMessageV3.BuilderParent parent) {
                super(parent);
                maybeForceBuilderInitialization();
            }
            private void maybeForceBuilderInitialization() {
                if (com.google.protobuf.GeneratedMessageV3
                        .alwaysUseFieldBuilders) {
                }
            }
            public Builder clear() {
                super.clear();
                name_ = "";

                score_ = 0;

                return this;
            }

            public com.google.protobuf.Descriptors.Descriptor
            getDescriptorForType() {
                return assignment.ResultProto.internal_static_CourseMarks_descriptor;
            }

            public assignment.ResultProto.CourseMarks getDefaultInstanceForType() {
                return assignment.ResultProto.CourseMarks.getDefaultInstance();
            }

            public assignment.ResultProto.CourseMarks build() {
                assignment.ResultProto.CourseMarks result = buildPartial();
                if (!result.isInitialized()) {
                    throw newUninitializedMessageException(result);
                }
                return result;
            }

            public assignment.ResultProto.CourseMarks buildPartial() {
                assignment.ResultProto.CourseMarks result = new assignment.ResultProto.CourseMarks(this);
                result.name_ = name_;
                result.score_ = score_;
                onBuilt();
                return result;
            }

            public Builder clone() {
                return (Builder) super.clone();
            }
            public Builder setField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    Object value) {
                return (Builder) super.setField(field, value);
            }
            public Builder clearField(
                    com.google.protobuf.Descriptors.FieldDescriptor field) {
                return (Builder) super.clearField(field);
            }
            public Builder clearOneof(
                    com.google.protobuf.Descriptors.OneofDescriptor oneof) {
                return (Builder) super.clearOneof(oneof);
            }
            public Builder setRepeatedField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    int index, Object value) {
                return (Builder) super.setRepeatedField(field, index, value);
            }
            public Builder addRepeatedField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    Object value) {
                return (Builder) super.addRepeatedField(field, value);
            }
            public Builder mergeFrom(com.google.protobuf.Message other) {
                if (other instanceof assignment.ResultProto.CourseMarks) {
                    return mergeFrom((assignment.ResultProto.CourseMarks)other);
                } else {
                    super.mergeFrom(other);
                    return this;
                }
            }

            public Builder mergeFrom(assignment.ResultProto.CourseMarks other) {
                if (other == assignment.ResultProto.CourseMarks.getDefaultInstance()) return this;
                if (!other.getName().isEmpty()) {
                    name_ = other.name_;
                    onChanged();
                }
                if (other.getScore() != 0) {
                    setScore(other.getScore());
                }
                onChanged();
                return this;
            }

            public final boolean isInitialized() {
                return true;
            }

            public Builder mergeFrom(
                    com.google.protobuf.CodedInputStream input,
                    com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                    throws java.io.IOException {
                assignment.ResultProto.CourseMarks parsedMessage = null;
                try {
                    parsedMessage = PARSER.parsePartialFrom(input, extensionRegistry);
                } catch (com.google.protobuf.InvalidProtocolBufferException e) {
                    parsedMessage = (assignment.ResultProto.CourseMarks) e.getUnfinishedMessage();
                    throw e.unwrapIOException();
                } finally {
                    if (parsedMessage != null) {
                        mergeFrom(parsedMessage);
                    }
                }
                return this;
            }

            private java.lang.Object name_ = "";
            /**
             * <code>optional string name = 1;</code>
             */
            public java.lang.String getName() {
                java.lang.Object ref = name_;
                if (!(ref instanceof java.lang.String)) {
                    com.google.protobuf.ByteString bs =
                            (com.google.protobuf.ByteString) ref;
                    java.lang.String s = bs.toStringUtf8();
                    name_ = s;
                    return s;
                } else {
                    return (java.lang.String) ref;
                }
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public com.google.protobuf.ByteString
            getNameBytes() {
                java.lang.Object ref = name_;
                if (ref instanceof String) {
                    com.google.protobuf.ByteString b =
                            com.google.protobuf.ByteString.copyFromUtf8(
                                    (java.lang.String) ref);
                    name_ = b;
                    return b;
                } else {
                    return (com.google.protobuf.ByteString) ref;
                }
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public Builder setName(
                    java.lang.String value) {
                if (value == null) {
                    throw new NullPointerException();
                }

                name_ = value;
                onChanged();
                return this;
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public Builder clearName() {

                name_ = getDefaultInstance().getName();
                onChanged();
                return this;
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public Builder setNameBytes(
                    com.google.protobuf.ByteString value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                checkByteStringIsUtf8(value);

                name_ = value;
                onChanged();
                return this;
            }

            private int score_ ;
            /**
             * <code>optional int32 score = 2;</code>
             */
            public int getScore() {
                return score_;
            }
            /**
             * <code>optional int32 score = 2;</code>
             */
            public Builder setScore(int value) {

                score_ = value;
                onChanged();
                return this;
            }
            /**
             * <code>optional int32 score = 2;</code>
             */
            public Builder clearScore() {

                score_ = 0;
                onChanged();
                return this;
            }
            public final Builder setUnknownFields(
                    final com.google.protobuf.UnknownFieldSet unknownFields) {
                return this;
            }

            public final Builder mergeUnknownFields(
                    final com.google.protobuf.UnknownFieldSet unknownFields) {
                return this;
            }


            // @@protoc_insertion_point(builder_scope:CourseMarks)
        }

        // @@protoc_insertion_point(class_scope:CourseMarks)
        private static final assignment.ResultProto.CourseMarks DEFAULT_INSTANCE;
        static {
            DEFAULT_INSTANCE = new assignment.ResultProto.CourseMarks();
        }

        public static assignment.ResultProto.CourseMarks getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private static final com.google.protobuf.Parser<CourseMarks>
                PARSER = new com.google.protobuf.AbstractParser<CourseMarks>() {
            public CourseMarks parsePartialFrom(
                    com.google.protobuf.CodedInputStream input,
                    com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                    throws com.google.protobuf.InvalidProtocolBufferException {
                return new CourseMarks(input, extensionRegistry);
            }
        };

        public static com.google.protobuf.Parser<CourseMarks> parser() {
            return PARSER;
        }

        @java.lang.Override
        public com.google.protobuf.Parser<CourseMarks> getParserForType() {
            return PARSER;
        }

        public assignment.ResultProto.CourseMarks getDefaultInstanceForType() {
            return DEFAULT_INSTANCE;
        }

    }

    public interface StudentOrBuilder extends
            // @@protoc_insertion_point(interface_extends:Student)
            com.google.protobuf.MessageOrBuilder {

        /**
         * <code>optional string name = 1;</code>
         */
        java.lang.String getName();
        /**
         * <code>optional string name = 1;</code>
         */
        com.google.protobuf.ByteString
        getNameBytes();

        /**
         * <code>optional int32 rollNum = 2;</code>
         */
        int getRollNum();

        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        java.util.List<assignment.ResultProto.CourseMarks>
        getMarksList();
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        assignment.ResultProto.CourseMarks getMarks(int index);
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        int getMarksCount();
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        java.util.List<? extends assignment.ResultProto.CourseMarksOrBuilder>
        getMarksOrBuilderList();
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        assignment.ResultProto.CourseMarksOrBuilder getMarksOrBuilder(
                int index);
    }
    /**
     * Protobuf type {@code Student}
     */
    public  static final class Student extends
            com.google.protobuf.GeneratedMessageV3 implements
            // @@protoc_insertion_point(message_implements:Student)
            StudentOrBuilder {
        // Use Student.newBuilder() to construct.
        private Student(com.google.protobuf.GeneratedMessageV3.Builder<?> builder) {
            super(builder);
        }
        private Student() {
            name_ = "";
            rollNum_ = 0;
            marks_ = java.util.Collections.emptyList();
        }

        @java.lang.Override
        public final com.google.protobuf.UnknownFieldSet
        getUnknownFields() {
            return com.google.protobuf.UnknownFieldSet.getDefaultInstance();
        }
        private Student(
                com.google.protobuf.CodedInputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            this();
            int mutable_bitField0_ = 0;
            try {
                boolean done = false;
                while (!done) {
                    int tag = input.readTag();
                    switch (tag) {
                        case 0:
                            done = true;
                            break;
                        default: {
                            if (!input.skipField(tag)) {
                                done = true;
                            }
                            break;
                        }
                        case 10: {
                            java.lang.String s = input.readStringRequireUtf8();

                            name_ = s;
                            break;
                        }
                        case 16: {

                            rollNum_ = input.readInt32();
                            break;
                        }
                        case 26: {
                            if (!((mutable_bitField0_ & 0x00000004) == 0x00000004)) {
                                marks_ = new java.util.ArrayList<assignment.ResultProto.CourseMarks>();
                                mutable_bitField0_ |= 0x00000004;
                            }
                            marks_.add(
                                    input.readMessage(assignment.ResultProto.CourseMarks.parser(), extensionRegistry));
                            break;
                        }
                    }
                }
            } catch (com.google.protobuf.InvalidProtocolBufferException e) {
                throw e.setUnfinishedMessage(this);
            } catch (java.io.IOException e) {
                throw new com.google.protobuf.InvalidProtocolBufferException(
                        e).setUnfinishedMessage(this);
            } finally {
                if (((mutable_bitField0_ & 0x00000004) == 0x00000004)) {
                    marks_ = java.util.Collections.unmodifiableList(marks_);
                }
                makeExtensionsImmutable();
            }
        }
        public static final com.google.protobuf.Descriptors.Descriptor
        getDescriptor() {
            return assignment.ResultProto.internal_static_Student_descriptor;
        }

        protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
        internalGetFieldAccessorTable() {
            return assignment.ResultProto.internal_static_Student_fieldAccessorTable
                    .ensureFieldAccessorsInitialized(
                            assignment.ResultProto.Student.class, assignment.ResultProto.Student.Builder.class);
        }

        private int bitField0_;
        public static final int NAME_FIELD_NUMBER = 1;
        private volatile java.lang.Object name_;
        /**
         * <code>optional string name = 1;</code>
         */
        public java.lang.String getName() {
            java.lang.Object ref = name_;
            if (ref instanceof java.lang.String) {
                return (java.lang.String) ref;
            } else {
                com.google.protobuf.ByteString bs =
                        (com.google.protobuf.ByteString) ref;
                java.lang.String s = bs.toStringUtf8();
                name_ = s;
                return s;
            }
        }
        /**
         * <code>optional string name = 1;</code>
         */
        public com.google.protobuf.ByteString
        getNameBytes() {
            java.lang.Object ref = name_;
            if (ref instanceof java.lang.String) {
                com.google.protobuf.ByteString b =
                        com.google.protobuf.ByteString.copyFromUtf8(
                                (java.lang.String) ref);
                name_ = b;
                return b;
            } else {
                return (com.google.protobuf.ByteString) ref;
            }
        }

        public static final int ROLLNUM_FIELD_NUMBER = 2;
        private int rollNum_;
        /**
         * <code>optional int32 rollNum = 2;</code>
         */
        public int getRollNum() {
            return rollNum_;
        }

        public static final int MARKS_FIELD_NUMBER = 3;
        private java.util.List<assignment.ResultProto.CourseMarks> marks_;
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        public java.util.List<assignment.ResultProto.CourseMarks> getMarksList() {
            return marks_;
        }
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        public java.util.List<? extends assignment.ResultProto.CourseMarksOrBuilder>
        getMarksOrBuilderList() {
            return marks_;
        }
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        public int getMarksCount() {
            return marks_.size();
        }
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        public assignment.ResultProto.CourseMarks getMarks(int index) {
            return marks_.get(index);
        }
        /**
         * <code>repeated .CourseMarks marks = 3;</code>
         */
        public assignment.ResultProto.CourseMarksOrBuilder getMarksOrBuilder(
                int index) {
            return marks_.get(index);
        }

        private byte memoizedIsInitialized = -1;
        public final boolean isInitialized() {
            byte isInitialized = memoizedIsInitialized;
            if (isInitialized == 1) return true;
            if (isInitialized == 0) return false;

            memoizedIsInitialized = 1;
            return true;
        }

        public void writeTo(com.google.protobuf.CodedOutputStream output)
                throws java.io.IOException {
            if (!getNameBytes().isEmpty()) {
                com.google.protobuf.GeneratedMessageV3.writeString(output, 1, name_);
            }
            if (rollNum_ != 0) {
                output.writeInt32(2, rollNum_);
            }
            for (int i = 0; i < marks_.size(); i++) {
                output.writeMessage(3, marks_.get(i));
            }
        }

        public int getSerializedSize() {
            int size = memoizedSize;
            if (size != -1) return size;

            size = 0;
            if (!getNameBytes().isEmpty()) {
                size += com.google.protobuf.GeneratedMessageV3.computeStringSize(1, name_);
            }
            if (rollNum_ != 0) {
                size += com.google.protobuf.CodedOutputStream
                        .computeInt32Size(2, rollNum_);
            }
            for (int i = 0; i < marks_.size(); i++) {
                size += com.google.protobuf.CodedOutputStream
                        .computeMessageSize(3, marks_.get(i));
            }
            memoizedSize = size;
            return size;
        }

        private static final long serialVersionUID = 0L;
        @java.lang.Override
        public boolean equals(final java.lang.Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof assignment.ResultProto.Student)) {
                return super.equals(obj);
            }
            assignment.ResultProto.Student other = (assignment.ResultProto.Student) obj;

            boolean result = true;
            result = result && getName()
                    .equals(other.getName());
            result = result && (getRollNum()
                    == other.getRollNum());
            result = result && getMarksList()
                    .equals(other.getMarksList());
            return result;
        }

        @java.lang.Override
        public int hashCode() {
            if (memoizedHashCode != 0) {
                return memoizedHashCode;
            }
            int hash = 41;
            hash = (19 * hash) + getDescriptorForType().hashCode();
            hash = (37 * hash) + NAME_FIELD_NUMBER;
            hash = (53 * hash) + getName().hashCode();
            hash = (37 * hash) + ROLLNUM_FIELD_NUMBER;
            hash = (53 * hash) + getRollNum();
            if (getMarksCount() > 0) {
                hash = (37 * hash) + MARKS_FIELD_NUMBER;
                hash = (53 * hash) + getMarksList().hashCode();
            }
            hash = (29 * hash) + unknownFields.hashCode();
            memoizedHashCode = hash;
            return hash;
        }

        public static assignment.ResultProto.Student parseFrom(
                com.google.protobuf.ByteString data)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data);
        }
        public static assignment.ResultProto.Student parseFrom(
                com.google.protobuf.ByteString data,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data, extensionRegistry);
        }
        public static assignment.ResultProto.Student parseFrom(byte[] data)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data);
        }
        public static assignment.ResultProto.Student parseFrom(
                byte[] data,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data, extensionRegistry);
        }
        public static assignment.ResultProto.Student parseFrom(java.io.InputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.Student parseFrom(
                java.io.InputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input, extensionRegistry);
        }
        public static assignment.ResultProto.Student parseDelimitedFrom(java.io.InputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseDelimitedWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.Student parseDelimitedFrom(
                java.io.InputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseDelimitedWithIOException(PARSER, input, extensionRegistry);
        }
        public static assignment.ResultProto.Student parseFrom(
                com.google.protobuf.CodedInputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.Student parseFrom(
                com.google.protobuf.CodedInputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input, extensionRegistry);
        }

        public Builder newBuilderForType() { return newBuilder(); }
        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.toBuilder();
        }
        public static Builder newBuilder(assignment.ResultProto.Student prototype) {
            return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
        }
        public Builder toBuilder() {
            return this == DEFAULT_INSTANCE
                    ? new Builder() : new Builder().mergeFrom(this);
        }

        @java.lang.Override
        protected Builder newBuilderForType(
                com.google.protobuf.GeneratedMessageV3.BuilderParent parent) {
            Builder builder = new Builder(parent);
            return builder;
        }
        /**
         * Protobuf type {@code Student}
         */
        public static final class Builder extends
                com.google.protobuf.GeneratedMessageV3.Builder<Builder> implements
                // @@protoc_insertion_point(builder_implements:Student)
                assignment.ResultProto.StudentOrBuilder {
            public static final com.google.protobuf.Descriptors.Descriptor
            getDescriptor() {
                return assignment.ResultProto.internal_static_Student_descriptor;
            }

            protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
            internalGetFieldAccessorTable() {
                return assignment.ResultProto.internal_static_Student_fieldAccessorTable
                        .ensureFieldAccessorsInitialized(
                                assignment.ResultProto.Student.class, assignment.ResultProto.Student.Builder.class);
            }

            // Construct using assignment.ResultProto.Student.newBuilder()
            private Builder() {
                maybeForceBuilderInitialization();
            }

            private Builder(
                    com.google.protobuf.GeneratedMessageV3.BuilderParent parent) {
                super(parent);
                maybeForceBuilderInitialization();
            }
            private void maybeForceBuilderInitialization() {
                if (com.google.protobuf.GeneratedMessageV3
                        .alwaysUseFieldBuilders) {
                    getMarksFieldBuilder();
                }
            }
            public Builder clear() {
                super.clear();
                name_ = "";

                rollNum_ = 0;

                if (marksBuilder_ == null) {
                    marks_ = java.util.Collections.emptyList();
                    bitField0_ = (bitField0_ & ~0x00000004);
                } else {
                    marksBuilder_.clear();
                }
                return this;
            }

            public com.google.protobuf.Descriptors.Descriptor
            getDescriptorForType() {
                return assignment.ResultProto.internal_static_Student_descriptor;
            }

            public assignment.ResultProto.Student getDefaultInstanceForType() {
                return assignment.ResultProto.Student.getDefaultInstance();
            }

            public assignment.ResultProto.Student build() {
                assignment.ResultProto.Student result = buildPartial();
                if (!result.isInitialized()) {
                    throw newUninitializedMessageException(result);
                }
                return result;
            }

            public assignment.ResultProto.Student buildPartial() {
                assignment.ResultProto.Student result = new assignment.ResultProto.Student(this);
                int from_bitField0_ = bitField0_;
                int to_bitField0_ = 0;
                result.name_ = name_;
                result.rollNum_ = rollNum_;
                if (marksBuilder_ == null) {
                    if (((bitField0_ & 0x00000004) == 0x00000004)) {
                        marks_ = java.util.Collections.unmodifiableList(marks_);
                        bitField0_ = (bitField0_ & ~0x00000004);
                    }
                    result.marks_ = marks_;
                } else {
                    result.marks_ = marksBuilder_.build();
                }
                result.bitField0_ = to_bitField0_;
                onBuilt();
                return result;
            }

            public Builder clone() {
                return (Builder) super.clone();
            }
            public Builder setField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    Object value) {
                return (Builder) super.setField(field, value);
            }
            public Builder clearField(
                    com.google.protobuf.Descriptors.FieldDescriptor field) {
                return (Builder) super.clearField(field);
            }
            public Builder clearOneof(
                    com.google.protobuf.Descriptors.OneofDescriptor oneof) {
                return (Builder) super.clearOneof(oneof);
            }
            public Builder setRepeatedField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    int index, Object value) {
                return (Builder) super.setRepeatedField(field, index, value);
            }
            public Builder addRepeatedField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    Object value) {
                return (Builder) super.addRepeatedField(field, value);
            }
            public Builder mergeFrom(com.google.protobuf.Message other) {
                if (other instanceof assignment.ResultProto.Student) {
                    return mergeFrom((assignment.ResultProto.Student)other);
                } else {
                    super.mergeFrom(other);
                    return this;
                }
            }

            public Builder mergeFrom(assignment.ResultProto.Student other) {
                if (other == assignment.ResultProto.Student.getDefaultInstance()) return this;
                if (!other.getName().isEmpty()) {
                    name_ = other.name_;
                    onChanged();
                }
                if (other.getRollNum() != 0) {
                    setRollNum(other.getRollNum());
                }
                if (marksBuilder_ == null) {
                    if (!other.marks_.isEmpty()) {
                        if (marks_.isEmpty()) {
                            marks_ = other.marks_;
                            bitField0_ = (bitField0_ & ~0x00000004);
                        } else {
                            ensureMarksIsMutable();
                            marks_.addAll(other.marks_);
                        }
                        onChanged();
                    }
                } else {
                    if (!other.marks_.isEmpty()) {
                        if (marksBuilder_.isEmpty()) {
                            marksBuilder_.dispose();
                            marksBuilder_ = null;
                            marks_ = other.marks_;
                            bitField0_ = (bitField0_ & ~0x00000004);
                            marksBuilder_ =
                                    com.google.protobuf.GeneratedMessageV3.alwaysUseFieldBuilders ?
                                            getMarksFieldBuilder() : null;
                        } else {
                            marksBuilder_.addAllMessages(other.marks_);
                        }
                    }
                }
                onChanged();
                return this;
            }

            public final boolean isInitialized() {
                return true;
            }

            public Builder mergeFrom(
                    com.google.protobuf.CodedInputStream input,
                    com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                    throws java.io.IOException {
                assignment.ResultProto.Student parsedMessage = null;
                try {
                    parsedMessage = PARSER.parsePartialFrom(input, extensionRegistry);
                } catch (com.google.protobuf.InvalidProtocolBufferException e) {
                    parsedMessage = (assignment.ResultProto.Student) e.getUnfinishedMessage();
                    throw e.unwrapIOException();
                } finally {
                    if (parsedMessage != null) {
                        mergeFrom(parsedMessage);
                    }
                }
                return this;
            }
            private int bitField0_;

            private java.lang.Object name_ = "";
            /**
             * <code>optional string name = 1;</code>
             */
            public java.lang.String getName() {
                java.lang.Object ref = name_;
                if (!(ref instanceof java.lang.String)) {
                    com.google.protobuf.ByteString bs =
                            (com.google.protobuf.ByteString) ref;
                    java.lang.String s = bs.toStringUtf8();
                    name_ = s;
                    return s;
                } else {
                    return (java.lang.String) ref;
                }
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public com.google.protobuf.ByteString
            getNameBytes() {
                java.lang.Object ref = name_;
                if (ref instanceof String) {
                    com.google.protobuf.ByteString b =
                            com.google.protobuf.ByteString.copyFromUtf8(
                                    (java.lang.String) ref);
                    name_ = b;
                    return b;
                } else {
                    return (com.google.protobuf.ByteString) ref;
                }
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public Builder setName(
                    java.lang.String value) {
                if (value == null) {
                    throw new NullPointerException();
                }

                name_ = value;
                onChanged();
                return this;
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public Builder clearName() {

                name_ = getDefaultInstance().getName();
                onChanged();
                return this;
            }
            /**
             * <code>optional string name = 1;</code>
             */
            public Builder setNameBytes(
                    com.google.protobuf.ByteString value) {
                if (value == null) {
                    throw new NullPointerException();
                }
                checkByteStringIsUtf8(value);

                name_ = value;
                onChanged();
                return this;
            }

            private int rollNum_ ;
            /**
             * <code>optional int32 rollNum = 2;</code>
             */
            public int getRollNum() {
                return rollNum_;
            }
            /**
             * <code>optional int32 rollNum = 2;</code>
             */
            public Builder setRollNum(int value) {

                rollNum_ = value;
                onChanged();
                return this;
            }
            /**
             * <code>optional int32 rollNum = 2;</code>
             */
            public Builder clearRollNum() {

                rollNum_ = 0;
                onChanged();
                return this;
            }

            private java.util.List<assignment.ResultProto.CourseMarks> marks_ =
                    java.util.Collections.emptyList();
            private void ensureMarksIsMutable() {
                if (!((bitField0_ & 0x00000004) == 0x00000004)) {
                    marks_ = new java.util.ArrayList<assignment.ResultProto.CourseMarks>(marks_);
                    bitField0_ |= 0x00000004;
                }
            }

            private com.google.protobuf.RepeatedFieldBuilderV3<
                    assignment.ResultProto.CourseMarks, assignment.ResultProto.CourseMarks.Builder, assignment.ResultProto.CourseMarksOrBuilder> marksBuilder_;

            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public java.util.List<assignment.ResultProto.CourseMarks> getMarksList() {
                if (marksBuilder_ == null) {
                    return java.util.Collections.unmodifiableList(marks_);
                } else {
                    return marksBuilder_.getMessageList();
                }
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public int getMarksCount() {
                if (marksBuilder_ == null) {
                    return marks_.size();
                } else {
                    return marksBuilder_.getCount();
                }
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public assignment.ResultProto.CourseMarks getMarks(int index) {
                if (marksBuilder_ == null) {
                    return marks_.get(index);
                } else {
                    return marksBuilder_.getMessage(index);
                }
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder setMarks(
                    int index, assignment.ResultProto.CourseMarks value) {
                if (marksBuilder_ == null) {
                    if (value == null) {
                        throw new NullPointerException();
                    }
                    ensureMarksIsMutable();
                    marks_.set(index, value);
                    onChanged();
                } else {
                    marksBuilder_.setMessage(index, value);
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder setMarks(
                    int index, assignment.ResultProto.CourseMarks.Builder builderForValue) {
                if (marksBuilder_ == null) {
                    ensureMarksIsMutable();
                    marks_.set(index, builderForValue.build());
                    onChanged();
                } else {
                    marksBuilder_.setMessage(index, builderForValue.build());
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder addMarks(assignment.ResultProto.CourseMarks value) {
                if (marksBuilder_ == null) {
                    if (value == null) {
                        throw new NullPointerException();
                    }
                    ensureMarksIsMutable();
                    marks_.add(value);
                    onChanged();
                } else {
                    marksBuilder_.addMessage(value);
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder addMarks(
                    int index, assignment.ResultProto.CourseMarks value) {
                if (marksBuilder_ == null) {
                    if (value == null) {
                        throw new NullPointerException();
                    }
                    ensureMarksIsMutable();
                    marks_.add(index, value);
                    onChanged();
                } else {
                    marksBuilder_.addMessage(index, value);
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder addMarks(
                    assignment.ResultProto.CourseMarks.Builder builderForValue) {
                if (marksBuilder_ == null) {
                    ensureMarksIsMutable();
                    marks_.add(builderForValue.build());
                    onChanged();
                } else {
                    marksBuilder_.addMessage(builderForValue.build());
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder addMarks(
                    int index, assignment.ResultProto.CourseMarks.Builder builderForValue) {
                if (marksBuilder_ == null) {
                    ensureMarksIsMutable();
                    marks_.add(index, builderForValue.build());
                    onChanged();
                } else {
                    marksBuilder_.addMessage(index, builderForValue.build());
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder addAllMarks(
                    java.lang.Iterable<? extends assignment.ResultProto.CourseMarks> values) {
                if (marksBuilder_ == null) {
                    ensureMarksIsMutable();
                    com.google.protobuf.AbstractMessageLite.Builder.addAll(
                            values, marks_);
                    onChanged();
                } else {
                    marksBuilder_.addAllMessages(values);
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder clearMarks() {
                if (marksBuilder_ == null) {
                    marks_ = java.util.Collections.emptyList();
                    bitField0_ = (bitField0_ & ~0x00000004);
                    onChanged();
                } else {
                    marksBuilder_.clear();
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public Builder removeMarks(int index) {
                if (marksBuilder_ == null) {
                    ensureMarksIsMutable();
                    marks_.remove(index);
                    onChanged();
                } else {
                    marksBuilder_.remove(index);
                }
                return this;
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public assignment.ResultProto.CourseMarks.Builder getMarksBuilder(
                    int index) {
                return getMarksFieldBuilder().getBuilder(index);
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public assignment.ResultProto.CourseMarksOrBuilder getMarksOrBuilder(
                    int index) {
                if (marksBuilder_ == null) {
                    return marks_.get(index);  } else {
                    return marksBuilder_.getMessageOrBuilder(index);
                }
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public java.util.List<? extends assignment.ResultProto.CourseMarksOrBuilder>
            getMarksOrBuilderList() {
                if (marksBuilder_ != null) {
                    return marksBuilder_.getMessageOrBuilderList();
                } else {
                    return java.util.Collections.unmodifiableList(marks_);
                }
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public assignment.ResultProto.CourseMarks.Builder addMarksBuilder() {
                return getMarksFieldBuilder().addBuilder(
                        assignment.ResultProto.CourseMarks.getDefaultInstance());
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public assignment.ResultProto.CourseMarks.Builder addMarksBuilder(
                    int index) {
                return getMarksFieldBuilder().addBuilder(
                        index, assignment.ResultProto.CourseMarks.getDefaultInstance());
            }
            /**
             * <code>repeated .CourseMarks marks = 3;</code>
             */
            public java.util.List<assignment.ResultProto.CourseMarks.Builder>
            getMarksBuilderList() {
                return getMarksFieldBuilder().getBuilderList();
            }
            private com.google.protobuf.RepeatedFieldBuilderV3<
                    assignment.ResultProto.CourseMarks, assignment.ResultProto.CourseMarks.Builder, assignment.ResultProto.CourseMarksOrBuilder>
            getMarksFieldBuilder() {
                if (marksBuilder_ == null) {
                    marksBuilder_ = new com.google.protobuf.RepeatedFieldBuilderV3<
                            assignment.ResultProto.CourseMarks, assignment.ResultProto.CourseMarks.Builder, assignment.ResultProto.CourseMarksOrBuilder>(
                            marks_,
                            ((bitField0_ & 0x00000004) == 0x00000004),
                            getParentForChildren(),
                            isClean());
                    marks_ = null;
                }
                return marksBuilder_;
            }
            public final Builder setUnknownFields(
                    final com.google.protobuf.UnknownFieldSet unknownFields) {
                return this;
            }

            public final Builder mergeUnknownFields(
                    final com.google.protobuf.UnknownFieldSet unknownFields) {
                return this;
            }


            // @@protoc_insertion_point(builder_scope:Student)
        }

        // @@protoc_insertion_point(class_scope:Student)
        private static final assignment.ResultProto.Student DEFAULT_INSTANCE;
        static {
            DEFAULT_INSTANCE = new assignment.ResultProto.Student();
        }

        public static assignment.ResultProto.Student getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private static final com.google.protobuf.Parser<Student>
                PARSER = new com.google.protobuf.AbstractParser<Student>() {
            public Student parsePartialFrom(
                    com.google.protobuf.CodedInputStream input,
                    com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                    throws com.google.protobuf.InvalidProtocolBufferException {
                return new Student(input, extensionRegistry);
            }
        };

        public static com.google.protobuf.Parser<Student> parser() {
            return PARSER;
        }

        @java.lang.Override
        public com.google.protobuf.Parser<Student> getParserForType() {
            return PARSER;
        }

        public assignment.ResultProto.Student getDefaultInstanceForType() {
            return DEFAULT_INSTANCE;
        }

    }

    public interface ResultOrBuilder extends
            // @@protoc_insertion_point(interface_extends:Result)
            com.google.protobuf.MessageOrBuilder {

        /**
         * <code>repeated .Student student = 1;</code>
         */
        java.util.List<assignment.ResultProto.Student>
        getStudentList();
        /**
         * <code>repeated .Student student = 1;</code>
         */
        assignment.ResultProto.Student getStudent(int index);
        /**
         * <code>repeated .Student student = 1;</code>
         */
        int getStudentCount();
        /**
         * <code>repeated .Student student = 1;</code>
         */
        java.util.List<? extends assignment.ResultProto.StudentOrBuilder>
        getStudentOrBuilderList();
        /**
         * <code>repeated .Student student = 1;</code>
         */
        assignment.ResultProto.StudentOrBuilder getStudentOrBuilder(
                int index);
    }
    /**
     * Protobuf type {@code Result}
     */
    public  static final class Result extends
            com.google.protobuf.GeneratedMessageV3 implements
            // @@protoc_insertion_point(message_implements:Result)
            ResultOrBuilder {
        // Use Result.newBuilder() to construct.
        private Result(com.google.protobuf.GeneratedMessageV3.Builder<?> builder) {
            super(builder);
        }
        private Result() {
            student_ = java.util.Collections.emptyList();
        }

        @java.lang.Override
        public final com.google.protobuf.UnknownFieldSet
        getUnknownFields() {
            return com.google.protobuf.UnknownFieldSet.getDefaultInstance();
        }
        private Result(
                com.google.protobuf.CodedInputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            this();
            int mutable_bitField0_ = 0;
            try {
                boolean done = false;
                while (!done) {
                    int tag = input.readTag();
                    switch (tag) {
                        case 0:
                            done = true;
                            break;
                        default: {
                            if (!input.skipField(tag)) {
                                done = true;
                            }
                            break;
                        }
                        case 10: {
                            if (!((mutable_bitField0_ & 0x00000001) == 0x00000001)) {
                                student_ = new java.util.ArrayList<assignment.ResultProto.Student>();
                                mutable_bitField0_ |= 0x00000001;
                            }
                            student_.add(
                                    input.readMessage(assignment.ResultProto.Student.parser(), extensionRegistry));
                            break;
                        }
                    }
                }
            } catch (com.google.protobuf.InvalidProtocolBufferException e) {
                throw e.setUnfinishedMessage(this);
            } catch (java.io.IOException e) {
                throw new com.google.protobuf.InvalidProtocolBufferException(
                        e).setUnfinishedMessage(this);
            } finally {
                if (((mutable_bitField0_ & 0x00000001) == 0x00000001)) {
                    student_ = java.util.Collections.unmodifiableList(student_);
                }
                makeExtensionsImmutable();
            }
        }
        public static final com.google.protobuf.Descriptors.Descriptor
        getDescriptor() {
            return assignment.ResultProto.internal_static_Result_descriptor;
        }

        protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
        internalGetFieldAccessorTable() {
            return assignment.ResultProto.internal_static_Result_fieldAccessorTable
                    .ensureFieldAccessorsInitialized(
                            assignment.ResultProto.Result.class, assignment.ResultProto.Result.Builder.class);
        }

        public static final int STUDENT_FIELD_NUMBER = 1;
        private java.util.List<assignment.ResultProto.Student> student_;
        /**
         * <code>repeated .Student student = 1;</code>
         */
        public java.util.List<assignment.ResultProto.Student> getStudentList() {
            return student_;
        }
        /**
         * <code>repeated .Student student = 1;</code>
         */
        public java.util.List<? extends assignment.ResultProto.StudentOrBuilder>
        getStudentOrBuilderList() {
            return student_;
        }
        /**
         * <code>repeated .Student student = 1;</code>
         */
        public int getStudentCount() {
            return student_.size();
        }
        /**
         * <code>repeated .Student student = 1;</code>
         */
        public assignment.ResultProto.Student getStudent(int index) {
            return student_.get(index);
        }
        /**
         * <code>repeated .Student student = 1;</code>
         */
        public assignment.ResultProto.StudentOrBuilder getStudentOrBuilder(
                int index) {
            return student_.get(index);
        }

        private byte memoizedIsInitialized = -1;
        public final boolean isInitialized() {
            byte isInitialized = memoizedIsInitialized;
            if (isInitialized == 1) return true;
            if (isInitialized == 0) return false;

            memoizedIsInitialized = 1;
            return true;
        }

        public void writeTo(com.google.protobuf.CodedOutputStream output)
                throws java.io.IOException {
            for (int i = 0; i < student_.size(); i++) {
                output.writeMessage(1, student_.get(i));
            }
        }

        public int getSerializedSize() {
            int size = memoizedSize;
            if (size != -1) return size;

            size = 0;
            for (int i = 0; i < student_.size(); i++) {
                size += com.google.protobuf.CodedOutputStream
                        .computeMessageSize(1, student_.get(i));
            }
            memoizedSize = size;
            return size;
        }

        private static final long serialVersionUID = 0L;
        @java.lang.Override
        public boolean equals(final java.lang.Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof assignment.ResultProto.Result)) {
                return super.equals(obj);
            }
            assignment.ResultProto.Result other = (assignment.ResultProto.Result) obj;

            boolean result = true;
            result = result && getStudentList()
                    .equals(other.getStudentList());
            return result;
        }

        @java.lang.Override
        public int hashCode() {
            if (memoizedHashCode != 0) {
                return memoizedHashCode;
            }
            int hash = 41;
            hash = (19 * hash) + getDescriptorForType().hashCode();
            if (getStudentCount() > 0) {
                hash = (37 * hash) + STUDENT_FIELD_NUMBER;
                hash = (53 * hash) + getStudentList().hashCode();
            }
            hash = (29 * hash) + unknownFields.hashCode();
            memoizedHashCode = hash;
            return hash;
        }

        public static assignment.ResultProto.Result parseFrom(
                com.google.protobuf.ByteString data)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data);
        }
        public static assignment.ResultProto.Result parseFrom(
                com.google.protobuf.ByteString data,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data, extensionRegistry);
        }
        public static assignment.ResultProto.Result parseFrom(byte[] data)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data);
        }
        public static assignment.ResultProto.Result parseFrom(
                byte[] data,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws com.google.protobuf.InvalidProtocolBufferException {
            return PARSER.parseFrom(data, extensionRegistry);
        }
        public static assignment.ResultProto.Result parseFrom(java.io.InputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.Result parseFrom(
                java.io.InputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input, extensionRegistry);
        }
        public static assignment.ResultProto.Result parseDelimitedFrom(java.io.InputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseDelimitedWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.Result parseDelimitedFrom(
                java.io.InputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseDelimitedWithIOException(PARSER, input, extensionRegistry);
        }
        public static assignment.ResultProto.Result parseFrom(
                com.google.protobuf.CodedInputStream input)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input);
        }
        public static assignment.ResultProto.Result parseFrom(
                com.google.protobuf.CodedInputStream input,
                com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                throws java.io.IOException {
            return com.google.protobuf.GeneratedMessageV3
                    .parseWithIOException(PARSER, input, extensionRegistry);
        }

        public Builder newBuilderForType() { return newBuilder(); }
        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.toBuilder();
        }
        public static Builder newBuilder(assignment.ResultProto.Result prototype) {
            return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
        }
        public Builder toBuilder() {
            return this == DEFAULT_INSTANCE
                    ? new Builder() : new Builder().mergeFrom(this);
        }

        @java.lang.Override
        protected Builder newBuilderForType(
                com.google.protobuf.GeneratedMessageV3.BuilderParent parent) {
            Builder builder = new Builder(parent);
            return builder;
        }
        /**
         * Protobuf type {@code Result}
         */
        public static final class Builder extends
                com.google.protobuf.GeneratedMessageV3.Builder<Builder> implements
                // @@protoc_insertion_point(builder_implements:Result)
                assignment.ResultProto.ResultOrBuilder {
            public static final com.google.protobuf.Descriptors.Descriptor
            getDescriptor() {
                return assignment.ResultProto.internal_static_Result_descriptor;
            }

            protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
            internalGetFieldAccessorTable() {
                return assignment.ResultProto.internal_static_Result_fieldAccessorTable
                        .ensureFieldAccessorsInitialized(
                                assignment.ResultProto.Result.class, assignment.ResultProto.Result.Builder.class);
            }

            // Construct using assignment.ResultProto.Result.newBuilder()
            private Builder() {
                maybeForceBuilderInitialization();
            }

            private Builder(
                    com.google.protobuf.GeneratedMessageV3.BuilderParent parent) {
                super(parent);
                maybeForceBuilderInitialization();
            }
            private void maybeForceBuilderInitialization() {
                if (com.google.protobuf.GeneratedMessageV3
                        .alwaysUseFieldBuilders) {
                    getStudentFieldBuilder();
                }
            }
            public Builder clear() {
                super.clear();
                if (studentBuilder_ == null) {
                    student_ = java.util.Collections.emptyList();
                    bitField0_ = (bitField0_ & ~0x00000001);
                } else {
                    studentBuilder_.clear();
                }
                return this;
            }

            public com.google.protobuf.Descriptors.Descriptor
            getDescriptorForType() {
                return assignment.ResultProto.internal_static_Result_descriptor;
            }

            public assignment.ResultProto.Result getDefaultInstanceForType() {
                return assignment.ResultProto.Result.getDefaultInstance();
            }

            public assignment.ResultProto.Result build() {
                assignment.ResultProto.Result result = buildPartial();
                if (!result.isInitialized()) {
                    throw newUninitializedMessageException(result);
                }
                return result;
            }

            public assignment.ResultProto.Result buildPartial() {
                assignment.ResultProto.Result result = new assignment.ResultProto.Result(this);
                int from_bitField0_ = bitField0_;
                if (studentBuilder_ == null) {
                    if (((bitField0_ & 0x00000001) == 0x00000001)) {
                        student_ = java.util.Collections.unmodifiableList(student_);
                        bitField0_ = (bitField0_ & ~0x00000001);
                    }
                    result.student_ = student_;
                } else {
                    result.student_ = studentBuilder_.build();
                }
                onBuilt();
                return result;
            }

            public Builder clone() {
                return (Builder) super.clone();
            }
            public Builder setField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    Object value) {
                return (Builder) super.setField(field, value);
            }
            public Builder clearField(
                    com.google.protobuf.Descriptors.FieldDescriptor field) {
                return (Builder) super.clearField(field);
            }
            public Builder clearOneof(
                    com.google.protobuf.Descriptors.OneofDescriptor oneof) {
                return (Builder) super.clearOneof(oneof);
            }
            public Builder setRepeatedField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    int index, Object value) {
                return (Builder) super.setRepeatedField(field, index, value);
            }
            public Builder addRepeatedField(
                    com.google.protobuf.Descriptors.FieldDescriptor field,
                    Object value) {
                return (Builder) super.addRepeatedField(field, value);
            }
            public Builder mergeFrom(com.google.protobuf.Message other) {
                if (other instanceof assignment.ResultProto.Result) {
                    return mergeFrom((assignment.ResultProto.Result)other);
                } else {
                    super.mergeFrom(other);
                    return this;
                }
            }

            public Builder mergeFrom(assignment.ResultProto.Result other) {
                if (other == assignment.ResultProto.Result.getDefaultInstance()) return this;
                if (studentBuilder_ == null) {
                    if (!other.student_.isEmpty()) {
                        if (student_.isEmpty()) {
                            student_ = other.student_;
                            bitField0_ = (bitField0_ & ~0x00000001);
                        } else {
                            ensureStudentIsMutable();
                            student_.addAll(other.student_);
                        }
                        onChanged();
                    }
                } else {
                    if (!other.student_.isEmpty()) {
                        if (studentBuilder_.isEmpty()) {
                            studentBuilder_.dispose();
                            studentBuilder_ = null;
                            student_ = other.student_;
                            bitField0_ = (bitField0_ & ~0x00000001);
                            studentBuilder_ =
                                    com.google.protobuf.GeneratedMessageV3.alwaysUseFieldBuilders ?
                                            getStudentFieldBuilder() : null;
                        } else {
                            studentBuilder_.addAllMessages(other.student_);
                        }
                    }
                }
                onChanged();
                return this;
            }

            public final boolean isInitialized() {
                return true;
            }

            public Builder mergeFrom(
                    com.google.protobuf.CodedInputStream input,
                    com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                    throws java.io.IOException {
                assignment.ResultProto.Result parsedMessage = null;
                try {
                    parsedMessage = PARSER.parsePartialFrom(input, extensionRegistry);
                } catch (com.google.protobuf.InvalidProtocolBufferException e) {
                    parsedMessage = (assignment.ResultProto.Result) e.getUnfinishedMessage();
                    throw e.unwrapIOException();
                } finally {
                    if (parsedMessage != null) {
                        mergeFrom(parsedMessage);
                    }
                }
                return this;
            }
            private int bitField0_;

            private java.util.List<assignment.ResultProto.Student> student_ =
                    java.util.Collections.emptyList();
            private void ensureStudentIsMutable() {
                if (!((bitField0_ & 0x00000001) == 0x00000001)) {
                    student_ = new java.util.ArrayList<assignment.ResultProto.Student>(student_);
                    bitField0_ |= 0x00000001;
                }
            }

            private com.google.protobuf.RepeatedFieldBuilderV3<
                    assignment.ResultProto.Student, assignment.ResultProto.Student.Builder, assignment.ResultProto.StudentOrBuilder> studentBuilder_;

            /**
             * <code>repeated .Student student = 1;</code>
             */
            public java.util.List<assignment.ResultProto.Student> getStudentList() {
                if (studentBuilder_ == null) {
                    return java.util.Collections.unmodifiableList(student_);
                } else {
                    return studentBuilder_.getMessageList();
                }
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public int getStudentCount() {
                if (studentBuilder_ == null) {
                    return student_.size();
                } else {
                    return studentBuilder_.getCount();
                }
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public assignment.ResultProto.Student getStudent(int index) {
                if (studentBuilder_ == null) {
                    return student_.get(index);
                } else {
                    return studentBuilder_.getMessage(index);
                }
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder setStudent(
                    int index, assignment.ResultProto.Student value) {
                if (studentBuilder_ == null) {
                    if (value == null) {
                        throw new NullPointerException();
                    }
                    ensureStudentIsMutable();
                    student_.set(index, value);
                    onChanged();
                } else {
                    studentBuilder_.setMessage(index, value);
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder setStudent(
                    int index, assignment.ResultProto.Student.Builder builderForValue) {
                if (studentBuilder_ == null) {
                    ensureStudentIsMutable();
                    student_.set(index, builderForValue.build());
                    onChanged();
                } else {
                    studentBuilder_.setMessage(index, builderForValue.build());
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder addStudent(assignment.ResultProto.Student value) {
                if (studentBuilder_ == null) {
                    if (value == null) {
                        throw new NullPointerException();
                    }
                    ensureStudentIsMutable();
                    student_.add(value);
                    onChanged();
                } else {
                    studentBuilder_.addMessage(value);
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder addStudent(
                    int index, assignment.ResultProto.Student value) {
                if (studentBuilder_ == null) {
                    if (value == null) {
                        throw new NullPointerException();
                    }
                    ensureStudentIsMutable();
                    student_.add(index, value);
                    onChanged();
                } else {
                    studentBuilder_.addMessage(index, value);
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder addStudent(
                    assignment.ResultProto.Student.Builder builderForValue) {
                if (studentBuilder_ == null) {
                    ensureStudentIsMutable();
                    student_.add(builderForValue.build());
                    onChanged();
                } else {
                    studentBuilder_.addMessage(builderForValue.build());
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder addStudent(
                    int index, assignment.ResultProto.Student.Builder builderForValue) {
                if (studentBuilder_ == null) {
                    ensureStudentIsMutable();
                    student_.add(index, builderForValue.build());
                    onChanged();
                } else {
                    studentBuilder_.addMessage(index, builderForValue.build());
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder addAllStudent(
                    java.lang.Iterable<? extends assignment.ResultProto.Student> values) {
                if (studentBuilder_ == null) {
                    ensureStudentIsMutable();
                    com.google.protobuf.AbstractMessageLite.Builder.addAll(
                            values, student_);
                    onChanged();
                } else {
                    studentBuilder_.addAllMessages(values);
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder clearStudent() {
                if (studentBuilder_ == null) {
                    student_ = java.util.Collections.emptyList();
                    bitField0_ = (bitField0_ & ~0x00000001);
                    onChanged();
                } else {
                    studentBuilder_.clear();
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public Builder removeStudent(int index) {
                if (studentBuilder_ == null) {
                    ensureStudentIsMutable();
                    student_.remove(index);
                    onChanged();
                } else {
                    studentBuilder_.remove(index);
                }
                return this;
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public assignment.ResultProto.Student.Builder getStudentBuilder(
                    int index) {
                return getStudentFieldBuilder().getBuilder(index);
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public assignment.ResultProto.StudentOrBuilder getStudentOrBuilder(
                    int index) {
                if (studentBuilder_ == null) {
                    return student_.get(index);  } else {
                    return studentBuilder_.getMessageOrBuilder(index);
                }
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public java.util.List<? extends assignment.ResultProto.StudentOrBuilder>
            getStudentOrBuilderList() {
                if (studentBuilder_ != null) {
                    return studentBuilder_.getMessageOrBuilderList();
                } else {
                    return java.util.Collections.unmodifiableList(student_);
                }
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public assignment.ResultProto.Student.Builder addStudentBuilder() {
                return getStudentFieldBuilder().addBuilder(
                        assignment.ResultProto.Student.getDefaultInstance());
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public assignment.ResultProto.Student.Builder addStudentBuilder(
                    int index) {
                return getStudentFieldBuilder().addBuilder(
                        index, assignment.ResultProto.Student.getDefaultInstance());
            }
            /**
             * <code>repeated .Student student = 1;</code>
             */
            public java.util.List<assignment.ResultProto.Student.Builder>
            getStudentBuilderList() {
                return getStudentFieldBuilder().getBuilderList();
            }
            private com.google.protobuf.RepeatedFieldBuilderV3<
                    assignment.ResultProto.Student, assignment.ResultProto.Student.Builder, assignment.ResultProto.StudentOrBuilder>
            getStudentFieldBuilder() {
                if (studentBuilder_ == null) {
                    studentBuilder_ = new com.google.protobuf.RepeatedFieldBuilderV3<
                            assignment.ResultProto.Student, assignment.ResultProto.Student.Builder, assignment.ResultProto.StudentOrBuilder>(
                            student_,
                            ((bitField0_ & 0x00000001) == 0x00000001),
                            getParentForChildren(),
                            isClean());
                    student_ = null;
                }
                return studentBuilder_;
            }
            public final Builder setUnknownFields(
                    final com.google.protobuf.UnknownFieldSet unknownFields) {
                return this;
            }

            public final Builder mergeUnknownFields(
                    final com.google.protobuf.UnknownFieldSet unknownFields) {
                return this;
            }


            // @@protoc_insertion_point(builder_scope:Result)
        }

        // @@protoc_insertion_point(class_scope:Result)
        private static final assignment.ResultProto.Result DEFAULT_INSTANCE;
        static {
            DEFAULT_INSTANCE = new assignment.ResultProto.Result();
        }

        public static assignment.ResultProto.Result getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private static final com.google.protobuf.Parser<Result>
                PARSER = new com.google.protobuf.AbstractParser<Result>() {
            public Result parsePartialFrom(
                    com.google.protobuf.CodedInputStream input,
                    com.google.protobuf.ExtensionRegistryLite extensionRegistry)
                    throws com.google.protobuf.InvalidProtocolBufferException {
                return new Result(input, extensionRegistry);
            }
        };

        public static com.google.protobuf.Parser<Result> parser() {
            return PARSER;
        }

        @java.lang.Override
        public com.google.protobuf.Parser<Result> getParserForType() {
            return PARSER;
        }

        public assignment.ResultProto.Result getDefaultInstanceForType() {
            return DEFAULT_INSTANCE;
        }

    }

    private static final com.google.protobuf.Descriptors.Descriptor
            internal_static_CourseMarks_descriptor;
    private static final
    com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
            internal_static_CourseMarks_fieldAccessorTable;
    private static final com.google.protobuf.Descriptors.Descriptor
            internal_static_Student_descriptor;
    private static final
    com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
            internal_static_Student_fieldAccessorTable;
    private static final com.google.protobuf.Descriptors.Descriptor
            internal_static_Result_descriptor;
    private static final
    com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
            internal_static_Result_fieldAccessorTable;

    public static com.google.protobuf.Descriptors.FileDescriptor
    getDescriptor() {
        return descriptor;
    }
    private static  com.google.protobuf.Descriptors.FileDescriptor
            descriptor;
    static {
        java.lang.String[] descriptorData = {
                "\n\014Result.proto\"*\n\013CourseMarks\022\014\n\004name\030\001 " +
                        "\001(\t\022\r\n\005score\030\002 \001(\005\"E\n\007Student\022\014\n\004name\030\001 " +
                        "\001(\t\022\017\n\007rollNum\030\002 \001(\005\022\033\n\005marks\030\003 \003(\0132\014.Co" +
                        "urseMarks\"#\n\006Result\022\031\n\007student\030\001 \003(\0132\010.S" +
                        "tudentB\031\n\nassignmentB\013ResultProtob\006proto" +
                        "3"
        };
        com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner assigner =
                new com.google.protobuf.Descriptors.FileDescriptor.    InternalDescriptorAssigner() {
                    public com.google.protobuf.ExtensionRegistry assignDescriptors(
                            com.google.protobuf.Descriptors.FileDescriptor root) {
                        descriptor = root;
                        return null;
                    }
                };
        com.google.protobuf.Descriptors.FileDescriptor
                .internalBuildGeneratedFileFrom(descriptorData,
                        new com.google.protobuf.Descriptors.FileDescriptor[] {
                        }, assigner);
        internal_static_CourseMarks_descriptor =
                getDescriptor().getMessageTypes().get(0);
        internal_static_CourseMarks_fieldAccessorTable = new
                com.google.protobuf.GeneratedMessageV3.FieldAccessorTable(
                internal_static_CourseMarks_descriptor,
                new java.lang.String[] { "Name", "Score", });
        internal_static_Student_descriptor =
                getDescriptor().getMessageTypes().get(1);
        internal_static_Student_fieldAccessorTable = new
                com.google.protobuf.GeneratedMessageV3.FieldAccessorTable(
                internal_static_Student_descriptor,
                new java.lang.String[] { "Name", "RollNum", "Marks", });
        internal_static_Result_descriptor =
                getDescriptor().getMessageTypes().get(2);
        internal_static_Result_fieldAccessorTable = new
                com.google.protobuf.GeneratedMessageV3.FieldAccessorTable(
                internal_static_Result_descriptor,
                new java.lang.String[] { "Student", });
    }

    // @@protoc_insertion_point(outer_class_scope)
}