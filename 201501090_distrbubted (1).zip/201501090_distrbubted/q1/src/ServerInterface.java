import assignment.ResultProto;

import java.io.UnsupportedEncodingException;
import java.rmi.Remote;
import java.rmi.RemoteException;

// Creating Remote interface for our application 
public interface ServerInterface extends Remote {
    void Receive(byte[] input)throws RemoteException,UnsupportedEncodingException;
    void ReceiveProtoBuf(byte[] input) throws RemoteException,UnsupportedEncodingException;

} 