**Build**
cd distributed_Assignment_1
javac src/com/nikhil/*.java -d  out/production/distributed_Assignment_1/
**RUN**
java com/nikhil/Main 8001 8002
java com/nikhil/Main 8002 8001

