package com.nikhil;

import java.io.IOException;

import static java.lang.Integer.parseInt;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int myport = parseInt(args[0]);
        int friendport = parseInt(args[1]);

        try {
            server server1 = new server(myport);
            server1.start();

        } catch (IOException e) {
            e.printStackTrace();
        }
        client client1 = null;
        try {
            client1 = new client(friendport);
        } catch (IOException e) {
            e.printStackTrace();
        }
        client1.start();
        System.out.print(">>");

    }
}
