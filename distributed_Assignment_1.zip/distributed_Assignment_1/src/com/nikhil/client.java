package com.nikhil;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

import static java.lang.Math.min;

public class client extends Thread{
    private Thread t;
    String serverName;
    Socket client;
    int port;
    public client(int clientport) throws IOException {
        serverName = "Bro";
        port = (clientport);

    }
    public void run() {
        while(true) {
            try {
                client = new Socket("localhost", port);
                OutputStream outToServer = client.getOutputStream();
                DataOutputStream out = new DataOutputStream(outToServer);
                Scanner scanner = new Scanner(System.in);

                // read string input
                String message = scanner.next();
                message += scanner.nextLine();
                out.writeUTF(message);
                if(message.startsWith("sending")) {
                    String[] splitted = message.split("\\s+");
                    sendFile("bin/send/" + splitted[1],splitted[2]);

                }
                System.out.print("\n>>");
                client.close();
            }catch(IOException e) {
                continue;
            }

        }
    }
    static void updateProgress(double progressPercentage, String file) {
        final int width = 50; // progress bar width in chars
        System.out.print("\rSending " + file + " [");
        int i = 0;
        for (; i <= (int)(progressPercentage*width); i++) {
            System.out.print("=");
        }
        System.out.print(">");
        for (; i < width; i++) {
            System.out.print(" ");
        }

        System.out.print("] " + (int)(progressPercentage*100) +"%");
    }
    public void sendFile(String file,String protocol) throws IOException {
        FileInputStream fis = null;
        DataOutputStream dos = new DataOutputStream(client.getOutputStream());

        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            dos.writeUTF("nofile");
            return;
        }

        long filelength = fis.getChannel().size();
        dos.writeUTF(protocol);
        dos.writeLong(filelength);
        if(protocol.equals("UDP")) {

            DatagramSocket ds = null;
            BufferedInputStream bis = null;
            try {
                ds = new DatagramSocket();
                DatagramPacket dp;
                int packetsize = 1024;
                double nosofpackets;
                nosofpackets = Math.ceil(((int) filelength / packetsize));
                bis = new BufferedInputStream(new FileInputStream(file));
                for (double i = 0; i < nosofpackets + 1; i++) {
                    byte[] mybytearray = new byte[packetsize];
                    bis.read(mybytearray, 0, mybytearray.length);
                    updateProgress((double)(i+1)/(double)(nosofpackets+1), file);
                    dp = new DatagramPacket(mybytearray, mybytearray.length, InetAddress.getByName("127.0.0.1"), port);
                    ds.send(dp);
                }
            }finally {
                if(bis!=null)
                    bis.close();
                if(ds !=null)
                    ds.close();
            }
            System.out.println("");
            System.out.println("Sent file");
            return;
        }

        byte[] buffer = new byte[4096];
        int read = 0;
        int totalRead = 0;
        int remaining = (int) filelength;

        while (fis.read(buffer) > 0) {
            totalRead += 4096;
            double x = min((double)totalRead/(double)filelength,1);
            updateProgress(x, file);
            dos.write(buffer);
        }
        System.out.println("");
        System.out.println("Sent file");
        fis.close();
        return;
    }
    public void start () {
        if (t == null) {
            t = new Thread (this, "client");
            t.start ();
        }
    }

}
