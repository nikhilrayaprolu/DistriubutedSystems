package com.nikhil;

import java.io.*;
import java.net.*;

import static java.lang.Math.min;

public class server extends Thread {
    private Thread t;
    private ServerSocket serverSocket;
    private DatagramSocket UDPSocket;

    public server(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        serverSocket.setSoTimeout(10000);
        UDPSocket = new DatagramSocket(port);

    }

    public void run() {

        while(true) {
            try {
                Socket server = serverSocket.accept();
                DataInputStream in = new DataInputStream(server.getInputStream());
                String message = in.readUTF();
                if(message.startsWith("sending")) {
                    String[] splitted = message.split("\\s+");
                    saveFile(server,splitted[1]);
                    message = "Received file";
                }
                System.out.println("");
                System.out.println(message);
                server.close();

            }catch(SocketTimeoutException s) {
                continue;
            }catch(IOException e) {
                e.printStackTrace();
                break;
            }
            System.out.print("\n>>");
        }
    }
    static void updateProgress(double progressPercentage, String file) {

        final int width = 50; // progress bar width in chars

        System.out.print("\rReceiving " + file + " [");
        int i = 0;
        for (; i <= (int)min((progressPercentage*width),100); i++) {
            System.out.print("=");
        }
        System.out.print(">");
        for (; i < width; i++) {
            System.out.print(" ");
        }
        System.out.print("] " +(int)(progressPercentage*100) +"%");
    }
    private void saveFile(Socket clientSock,String filename) throws IOException {
        DataInputStream dis = new DataInputStream(clientSock.getInputStream());
        String protocol = dis.readUTF();
        if(protocol.equals("nofile")) {

            return;
        }
        long filesize = dis.readLong();
        if (protocol.equals("UDP")) {
           UDPFileSave(filename,filesize);
           return;
        }
        FileOutputStream fos = new FileOutputStream("bin/receive/" + filename);
        byte[] buffer = new byte[4096];
        int read = 0;
        int totalRead = 0;
        int remaining = (int) filesize;
        while((read = dis.read(buffer, 0, min(buffer.length, remaining))) > 0) {
            totalRead += read;
            remaining -= read;
            String anim= "|/-\\";
            double x =((double)totalRead/(double) (totalRead + remaining));
            updateProgress(x,filename);
            fos.write(buffer, 0, read);
        }

        fos.close();
        return;
    }
    private void UDPFileSave(String filename,long filesize) throws IOException {
        int packetsize = 1024;
        FileOutputStream fos = null;
        fos = new FileOutputStream(filename);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            double nosofpackets = Math.ceil(((int) filesize / packetsize));
            byte[] mybytearray = new byte[packetsize];
            DatagramPacket receivePacket = new DatagramPacket(mybytearray, mybytearray.length);

            for (double i = 0; i < nosofpackets + 1; i++) {
                updateProgress((double)(i+1)/(double)(nosofpackets+1),filename);
                UDPSocket.receive(receivePacket);
                byte audioData[] = receivePacket.getData();
                bos.write(audioData, 0, audioData.length);
            }
            return;


    }
    public void start () {
        if (t == null) {
            t = new Thread (this, "server");
            t.start ();
        }
    }
}
